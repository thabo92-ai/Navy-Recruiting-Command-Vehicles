// This file defines the database schema for the Navy Recruiting Command Vehicle Management System
// It provides functions to create tables and set up the database structure in Supabase

import { supabase, getServiceSupabase } from './supabase';

// Create users table
export async function createUsersTable() {
  const { error } = await supabase
    .from('users')
    .insert({
      email: 'admin@navy.mil',
      full_name: 'Admin User',
      rank: 'Commander',
      phone: '555-123-4567',
      is_admin: true
    })
    .select()
    .single();
  
  // If table doesn't exist, we'll get an error
  if (error && error.code === '42P01') {
    console.log('Users table does not exist, creating it...');
    return true; // Table needs to be created
  } else if (!error) {
    console.log('Users table exists and is accessible');
    return false; // Table already exists
  } else {
    console.error('Error checking users table:', error);
    return true; // Assume table needs to be created
  }
}

// Create vehicles table
export async function createVehiclesTable() {
  const { error } = await supabase
    .from('vehicles')
    .insert({
      make: 'Ford',
      model: 'Explorer',
      year: 2023,
      color: 'Navy Blue',
      license_plate: 'NAVY-001',
      vin: '1FMSK8DH3PGB12345',
      current_mileage: 5000,
      fuel_capacity: 18.6,
      status: 'available',
      notes: 'Primary recruiting vehicle'
    })
    .select()
    .single();
  
  if (error && error.code === '42P01') {
    console.log('Vehicles table does not exist, creating it...');
    return true;
  } else if (!error) {
    console.log('Vehicles table exists and is accessible');
    return false;
  } else {
    console.error('Error checking vehicles table:', error);
    return true;
  }
}

// Create vehicle_checkouts table
export async function createVehicleCheckoutsTable() {
  const { error } = await supabase
    .from('vehicle_checkouts')
    .select()
    .limit(1);
  
  if (error && error.code === '42P01') {
    console.log('Vehicle checkouts table does not exist, creating it...');
    return true;
  } else if (!error) {
    console.log('Vehicle checkouts table exists and is accessible');
    return false;
  } else {
    console.error('Error checking vehicle checkouts table:', error);
    return true;
  }
}

// Create vehicle_checkins table
export async function createVehicleCheckinsTable() {
  const { error } = await supabase
    .from('vehicle_checkins')
    .select()
    .limit(1);
  
  if (error && error.code === '42P01') {
    console.log('Vehicle checkins table does not exist, creating it...');
    return true;
  } else if (!error) {
    console.log('Vehicle checkins table exists and is accessible');
    return false;
  } else {
    console.error('Error checking vehicle checkins table:', error);
    return true;
  }
}

// Create maintenance_records table
export async function createMaintenanceRecordsTable() {
  const { error } = await supabase
    .from('maintenance_records')
    .select()
    .limit(1);
  
  if (error && error.code === '42P01') {
    console.log('Maintenance records table does not exist, creating it...');
    return true;
  } else if (!error) {
    console.log('Maintenance records table exists and is accessible');
    return false;
  } else {
    console.error('Error checking maintenance records table:', error);
    return true;
  }
}

// Create notifications table
export async function createNotificationsTable() {
  const { error } = await supabase
    .from('notifications')
    .select()
    .limit(1);
  
  if (error && error.code === '42P01') {
    console.log('Notifications table does not exist, creating it...');
    return true;
  } else if (!error) {
    console.log('Notifications table exists and is accessible');
    return false;
  } else {
    console.error('Error checking notifications table:', error);
    return true;
  }
}

// Create system_logs table
export async function createSystemLogsTable() {
  const { error } = await supabase
    .from('system_logs')
    .select()
    .limit(1);
  
  if (error && error.code === '42P01') {
    console.log('System logs table does not exist, creating it...');
    return true;
  } else if (!error) {
    console.log('System logs table exists and is accessible');
    return false;
  } else {
    console.error('Error checking system logs table:', error);
    return true;
  }
}

// Initialize database schema
export async function initializeSchema() {
  console.log('Initializing database schema...');
  
  try {
    // Check if tables exist and create them if needed
    const needsUsersTable = await createUsersTable();
    const needsVehiclesTable = await createVehiclesTable();
    const needsCheckoutsTable = await createVehicleCheckoutsTable();
    const needsCheckinsTable = await createVehicleCheckinsTable();
    const needsMaintenanceTable = await createMaintenanceRecordsTable();
    const needsNotificationsTable = await createNotificationsTable();
    const needsLogsTable = await createSystemLogsTable();
    
    // If any tables need to be created, use the Supabase Dashboard to create them
    if (needsUsersTable || needsVehiclesTable || needsCheckoutsTable || 
        needsCheckinsTable || needsMaintenanceTable || needsNotificationsTable || 
        needsLogsTable) {
      console.log('Some tables need to be created. Please use the Supabase Dashboard to create the tables according to the schema in database-schema.md');
      
      // For demonstration purposes, we'll create some test data in existing tables
      await createTestData();
    } else {
      console.log('All tables exist and are accessible');
    }
    
    return { success: true, message: 'Database schema initialization completed' };
  } catch (error) {
    console.error('Error initializing database schema:', error);
    return { success: false, error: error.message };
  }
}

// Create test data for demonstration
async function createTestData() {
  try {
    // Create admin user if users table exists
    const { error: userError } = await supabase
      .from('users')
      .upsert([
        {
          email: 'admin@navy.mil',
          full_name: 'Admin User',
          rank: 'Commander',
          phone: '555-123-4567',
          is_admin: true
        },
        {
          email: 'recruiter@navy.mil',
          full_name: 'Navy Recruiter',
          rank: 'Petty Officer',
          phone: '555-987-6543',
          is_admin: false
        }
      ], { onConflict: 'email' });
    
    if (!userError) {
      console.log('Created test users');
    }
    
    // Create test vehicles if vehicles table exists
    const { error: vehicleError } = await supabase
      .from('vehicles')
      .upsert([
        {
          make: 'Ford',
          model: 'Explorer',
          year: 2023,
          color: 'Navy Blue',
          license_plate: 'NAVY-001',
          vin: '1FMSK8DH3PGB12345',
          current_mileage: 5000,
          fuel_capacity: 18.6,
          status: 'available',
          notes: 'Primary recruiting vehicle'
        },
        {
          make: 'Chevrolet',
          model: 'Tahoe',
          year: 2022,
          color: 'Black',
          license_plate: 'NAVY-002',
          vin: '1GNSKCKD2NR123456',
          current_mileage: 8500,
          fuel_capacity: 24.0,
          status: 'available',
          notes: 'Secondary recruiting vehicle'
        }
      ], { onConflict: 'license_plate' });
    
    if (!vehicleError) {
      console.log('Created test vehicles');
    }
    
  } catch (error) {
    console.error('Error creating test data:', error);
  }
}
