import { supabase } from './supabase';

// API functions for users
export const userAPI = {
  // Get all users
  async getAllUsers() {
    const { data, error } = await supabase
      .from('users')
      .select('*')
      .order('full_name');
    
    if (error) throw error;
    return data;
  },
  
  // Get user by ID
  async getUserById(id) {
    const { data, error } = await supabase
      .from('users')
      .select('*')
      .eq('id', id)
      .single();
    
    if (error) throw error;
    return data;
  },
  
  // Create new user
  async createUser(userData) {
    const { data, error } = await supabase
      .from('users')
      .insert([userData])
      .select();
    
    if (error) throw error;
    return data[0];
  },
  
  // Update user
  async updateUser(id, userData) {
    const { data, error } = await supabase
      .from('users')
      .update(userData)
      .eq('id', id)
      .select();
    
    if (error) throw error;
    return data[0];
  },
  
  // Delete user
  async deleteUser(id) {
    const { error } = await supabase
      .from('users')
      .delete()
      .eq('id', id);
    
    if (error) throw error;
    return true;
  }
};

// API functions for vehicles
export const vehicleAPI = {
  // Get all vehicles
  async getAllVehicles() {
    const { data, error } = await supabase
      .from('vehicles')
      .select('*')
      .order('make, model');
    
    if (error) throw error;
    return data;
  },
  
  // Get available vehicles
  async getAvailableVehicles() {
    const { data, error } = await supabase
      .from('vehicles')
      .select('*')
      .eq('status', 'available')
      .order('make, model');
    
    if (error) throw error;
    return data;
  },
  
  // Get vehicle by ID
  async getVehicleById(id) {
    const { data, error } = await supabase
      .from('vehicles')
      .select('*')
      .eq('id', id)
      .single();
    
    if (error) throw error;
    return data;
  },
  
  // Create new vehicle
  async createVehicle(vehicleData) {
    const { data, error } = await supabase
      .from('vehicles')
      .insert([vehicleData])
      .select();
    
    if (error) throw error;
    return data[0];
  },
  
  // Update vehicle
  async updateVehicle(id, vehicleData) {
    const { data, error } = await supabase
      .from('vehicles')
      .update(vehicleData)
      .eq('id', id)
      .select();
    
    if (error) throw error;
    return data[0];
  },
  
  // Delete vehicle
  async deleteVehicle(id) {
    const { error } = await supabase
      .from('vehicles')
      .delete()
      .eq('id', id);
    
    if (error) throw error;
    return true;
  },
  
  // Get vehicle by license plate
  async getVehicleByLicensePlate(licensePlate) {
    const { data, error } = await supabase
      .from('vehicles')
      .select('*')
      .eq('license_plate', licensePlate)
      .single();
    
    if (error) throw error;
    return data;
  },
  
  // Get vehicle by VIN
  async getVehicleByVIN(vin) {
    const { data, error } = await supabase
      .from('vehicles')
      .select('*')
      .eq('vin', vin)
      .single();
    
    if (error) throw error;
    return data;
  }
};

// API functions for vehicle checkouts
export const checkoutAPI = {
  // Get all checkouts
  async getAllCheckouts() {
    const { data, error } = await supabase
      .from('vehicle_checkouts')
      .select(`
        *,
        vehicles(*),
        users(*)
      `)
      .order('checkout_time', { ascending: false });
    
    if (error) throw error;
    return data;
  },
  
  // Get active checkouts
  async getActiveCheckouts() {
    const { data, error } = await supabase
      .from('vehicle_checkouts')
      .select(`
        *,
        vehicles(*),
        users(*)
      `)
      .eq('is_active', true)
      .order('checkout_time', { ascending: false });
    
    if (error) throw error;
    return data;
  },
  
  // Get checkout by ID
  async getCheckoutById(id) {
    const { data, error } = await supabase
      .from('vehicle_checkouts')
      .select(`
        *,
        vehicles(*),
        users(*)
      `)
      .eq('id', id)
      .single();
    
    if (error) throw error;
    return data;
  },
  
  // Create new checkout
  async createCheckout(checkoutData) {
    const { data, error } = await supabase
      .from('vehicle_checkouts')
      .insert([checkoutData])
      .select();
    
    if (error) throw error;
    return data[0];
  },
  
  // Update checkout
  async updateCheckout(id, checkoutData) {
    const { data, error } = await supabase
      .from('vehicle_checkouts')
      .update(checkoutData)
      .eq('id', id)
      .select();
    
    if (error) throw error;
    return data[0];
  },
  
  // Get checkouts by user ID
  async getCheckoutsByUserId(userId) {
    const { data, error } = await supabase
      .from('vehicle_checkouts')
      .select(`
        *,
        vehicles(*),
        users(*)
      `)
      .eq('user_id', userId)
      .order('checkout_time', { ascending: false });
    
    if (error) throw error;
    return data;
  },
  
  // Get active checkout by vehicle ID
  async getActiveCheckoutByVehicleId(vehicleId) {
    const { data, error } = await supabase
      .from('vehicle_checkouts')
      .select(`
        *,
        vehicles(*),
        users(*)
      `)
      .eq('vehicle_id', vehicleId)
      .eq('is_active', true)
      .single();
    
    if (error && error.code !== 'PGRST116') throw error; // PGRST116 is "No rows returned" error
    return data;
  }
};

// API functions for vehicle checkins
export const checkinAPI = {
  // Get all checkins
  async getAllCheckins() {
    const { data, error } = await supabase
      .from('vehicle_checkins')
      .select(`
        *,
        vehicle_checkouts(
          *,
          vehicles(*),
          users(*)
        )
      `)
      .order('checkin_time', { ascending: false });
    
    if (error) throw error;
    return data;
  },
  
  // Get checkin by ID
  async getCheckinById(id) {
    const { data, error } = await supabase
      .from('vehicle_checkins')
      .select(`
        *,
        vehicle_checkouts(
          *,
          vehicles(*),
          users(*)
        )
      `)
      .eq('id', id)
      .single();
    
    if (error) throw error;
    return data;
  },
  
  // Create new checkin
  async createCheckin(checkinData) {
    const { data, error } = await supabase
      .from('vehicle_checkins')
      .insert([checkinData])
      .select();
    
    if (error) throw error;
    return data[0];
  },
  
  // Get checkin by checkout ID
  async getCheckinByCheckoutId(checkoutId) {
    const { data, error } = await supabase
      .from('vehicle_checkins')
      .select(`
        *,
        vehicle_checkouts(
          *,
          vehicles(*),
          users(*)
        )
      `)
      .eq('checkout_id', checkoutId)
      .single();
    
    if (error && error.code !== 'PGRST116') throw error; // PGRST116 is "No rows returned" error
    return data;
  }
};

// API functions for maintenance records
export const maintenanceAPI = {
  // Get all maintenance records
  async getAllMaintenanceRecords() {
    const { data, error } = await supabase
      .from('maintenance_records')
      .select(`
        *,
        vehicles(*)
      `)
      .order('maintenance_date', { ascending: false });
    
    if (error) throw error;
    return data;
  },
  
  // Get maintenance record by ID
  async getMaintenanceRecordById(id) {
    const { data, error } = await supabase
      .from('maintenance_records')
      .select(`
        *,
        vehicles(*)
      `)
      .eq('id', id)
      .single();
    
    if (error) throw error;
    return data;
  },
  
  // Create new maintenance record
  async createMaintenanceRecord(maintenanceData) {
    const { data, error } = await supabase
      .from('maintenance_records')
      .insert([maintenanceData])
      .select();
    
    if (error) throw error;
    return data[0];
  },
  
  // Update maintenance record
  async updateMaintenanceRecord(id, maintenanceData) {
    const { data, error } = await supabase
      .from('maintenance_records')
      .update(maintenanceData)
      .eq('id', id)
      .select();
    
    if (error) throw error;
    return data[0];
  },
  
  // Delete maintenance record
  async deleteMaintenanceRecord(id) {
    const { error } = await supabase
      .from('maintenance_records')
      .delete()
      .eq('id', id);
    
    if (error) throw error;
    return true;
  },
  
  // Get maintenance records by vehicle ID
  async getMaintenanceRecordsByVehicleId(vehicleId) {
    const { data, error } = await supabase
      .from('maintenance_records')
      .select(`
        *,
        vehicles(*)
      `)
      .eq('vehicle_id', vehicleId)
      .order('maintenance_date', { ascending: false });
    
    if (error) throw error;
    return data;
  }
};

// API functions for notifications
export const notificationAPI = {
  // Get all notifications
  async getAllNotifications() {
    const { data, error } = await supabase
      .from('notifications')
      .select(`
        *,
        users(*),
        vehicles(*)
      `)
      .order('created_at', { ascending: false });
    
    if (error) throw error;
    return data;
  },
  
  // Get unread notifications
  async getUnreadNotifications() {
    const { data, error } = await supabase
      .from('notifications')
      .select(`
        *,
        users(*),
        vehicles(*)
      `)
      .eq('is_read', false)
      .order('created_at', { ascending: false });
    
    if (error) throw error;
    return data;
  },
  
  // Mark notification as read
  async markNotificationAsRead(id) {
    const { data, error } = await supabase
      .from('notifications')
      .update({ is_read: true })
      .eq('id', id)
      .select();
    
    if (error) throw error;
    return data[0];
  },
  
  // Get notifications by user ID
  async getNotificationsByUserId(userId) {
    const { data, error } = await supabase
      .from('notifications')
      .select(`
        *,
        users(*),
        vehicles(*)
      `)
      .eq('user_id', userId)
      .order('created_at', { ascending: false });
    
    if (error) throw error;
    return data;
  },
  
  // Create new notification
  async createNotification(notificationData) {
    const { data, error } = await supabase
      .from('notifications')
      .insert([notificationData])
      .select();
    
    if (error) throw error;
    return data[0];
  }
};

// API functions for system logs
export const systemLogAPI = {
  // Create new system log
  async createSystemLog(logData) {
    const { data, error } = await supabase
      .from('system_logs')
      .insert([logData])
      .select();
    
    if (error) throw error;
    return data[0];
  },
  
  // Get all system logs
  async getAllSystemLogs() {
    const { data, error } = await supabase
      .from('system_logs')
      .select(`
        *,
        users(*)
      `)
      .order('created_at', { ascending: false });
    
    if (error) throw error;
    return data;
  },
  
  // Get system logs by user ID
  async getSystemLogsByUserId(userId) {
    const { data, error } = await supabase
      .from('system_logs')
      .select(`
        *,
        users(*)
      `)
      .eq('user_id', userId)
      .order('created_at', { ascending: false });
    
    if (error) throw error;
    return data;
  }
};

// Execute the overdue vehicle notifications function
export const executeOverdueVehicleNotifications = async () => {
  try {
    await supabase.rpc('create_overdue_vehicle_notifications');
    return { success: true };
  } catch (error) {
    console.error('Error executing overdue vehicle notifications:', error);
    return { success: false, error: error.message };
  }
};
