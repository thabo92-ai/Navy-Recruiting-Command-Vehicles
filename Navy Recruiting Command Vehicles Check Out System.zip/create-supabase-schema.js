// This script creates the database schema in Supabase
const { createClient } = require('@supabase/supabase-js');

const supabaseUrl = 'https://tgzyqycyoyzrbgjvzvzx.supabase.co';
const supabaseServiceKey = 'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6InRnenlxeWN5b3l6cmJnanZ6dnp4Iiwicm9sZSI6InNlcnZpY2Vfcm9sZSIsImlhdCI6MTc0MzM3NTYwOSwiZXhwIjoyMDU4OTUxNjA5fQ.eMuA61Fk-5yPBVc0hm9nSOoQbo-qa5F90pYLlrF2mPw';

// Create Supabase client with service role key for admin operations
const serviceSupabase = createClient(supabaseUrl, supabaseServiceKey);

async function createSchema() {
  console.log('Starting database schema creation...');
  
  try {
    // Create users table
    console.log('Creating users table...');
    try {
      const { data, error } = await serviceSupabase
        .from('users')
        .select()
        .limit(1);
      
      if (error) {
        // Table doesn't exist or other error, try to create it
        const { error: createError } = await serviceSupabase
          .from('users')
          .insert([
            {
              email: 'test@example.com',
              full_name: 'Test User',
              is_admin: false
            }
          ]);
        
        if (createError && createError.code === '42P01') {
          // Table doesn't exist, create it using SQL
          console.log('Users table does not exist, creating it...');
          await serviceSupabase.sql(`
            CREATE TABLE IF NOT EXISTS users (
              id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
              email VARCHAR(255) UNIQUE NOT NULL,
              full_name VARCHAR(255) NOT NULL,
              rank VARCHAR(100),
              phone VARCHAR(20),
              is_admin BOOLEAN DEFAULT FALSE,
              created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
              updated_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
            );
          `);
        }
      }
    } catch (error) {
      console.log('Error checking users table:', error);
      
      // Try direct SQL approach
      try {
        await serviceSupabase.sql(`
          CREATE TABLE IF NOT EXISTS users (
            id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
            email VARCHAR(255) UNIQUE NOT NULL,
            full_name VARCHAR(255) NOT NULL,
            rank VARCHAR(100),
            phone VARCHAR(20),
            is_admin BOOLEAN DEFAULT FALSE,
            created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
            updated_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
          );
        `);
        console.log('Created users table using SQL');
      } catch (sqlError) {
        console.error('Error creating users table with SQL:', sqlError);
        return { success: false, error: sqlError };
      }
    }
    
    // Create vehicles table
    console.log('Creating vehicles table...');
    try {
      await serviceSupabase.sql(`
        CREATE TABLE IF NOT EXISTS vehicles (
          id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
          make VARCHAR(100) NOT NULL,
          model VARCHAR(100) NOT NULL,
          year INTEGER NOT NULL,
          color VARCHAR(50) NOT NULL,
          license_plate VARCHAR(20) UNIQUE NOT NULL,
          vin VARCHAR(17) UNIQUE NOT NULL,
          current_mileage INTEGER NOT NULL,
          fuel_capacity DECIMAL(5,2) NOT NULL,
          status VARCHAR(20) NOT NULL,
          qr_code_url VARCHAR(255),
          notes TEXT,
          created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
          updated_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
        );
      `);
      console.log('Created vehicles table');
    } catch (error) {
      console.error('Error creating vehicles table:', error);
      return { success: false, error };
    }
    
    // Create vehicle_checkouts table
    console.log('Creating vehicle_checkouts table...');
    try {
      await serviceSupabase.sql(`
        CREATE TABLE IF NOT EXISTS vehicle_checkouts (
          id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
          vehicle_id UUID NOT NULL,
          user_id UUID NOT NULL,
          checkout_time TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
          expected_return_time TIMESTAMP WITH TIME ZONE NOT NULL,
          destination VARCHAR(255) NOT NULL,
          purpose TEXT NOT NULL,
          starting_mileage INTEGER NOT NULL,
          starting_fuel_level DECIMAL(5,2) NOT NULL,
          condition_notes TEXT,
          condition_photos JSONB,
          is_active BOOLEAN DEFAULT TRUE,
          created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
          updated_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
        );
      `);
      console.log('Created vehicle_checkouts table');
    } catch (error) {
      console.error('Error creating vehicle_checkouts table:', error);
      return { success: false, error };
    }
    
    // Create vehicle_checkins table
    console.log('Creating vehicle_checkins table...');
    try {
      await serviceSupabase.sql(`
        CREATE TABLE IF NOT EXISTS vehicle_checkins (
          id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
          checkout_id UUID NOT NULL,
          checkin_time TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
          ending_mileage INTEGER NOT NULL,
          ending_fuel_level DECIMAL(5,2) NOT NULL,
          condition_notes TEXT,
          condition_photos JSONB,
          maintenance_issues TEXT,
          created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
          updated_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
        );
      `);
      console.log('Created vehicle_checkins table');
    } catch (error) {
      console.error('Error creating vehicle_checkins table:', error);
      return { success: false, error };
    }
    
    // Create maintenance_records table
    console.log('Creating maintenance_records table...');
    try {
      await serviceSupabase.sql(`
        CREATE TABLE IF NOT EXISTS maintenance_records (
          id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
          vehicle_id UUID NOT NULL,
          maintenance_type VARCHAR(100) NOT NULL,
          description TEXT NOT NULL,
          mileage_at_maintenance INTEGER NOT NULL,
          maintenance_date DATE NOT NULL,
          cost DECIMAL(10,2),
          performed_by VARCHAR(255),
          notes TEXT,
          created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
          updated_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
        );
      `);
      console.log('Created maintenance_records table');
    } catch (error) {
      console.error('Error creating maintenance_records table:', error);
      return { success: false, error };
    }
    
    // Create notifications table
    console.log('Creating notifications table...');
    try {
      await serviceSupabase.sql(`
        CREATE TABLE IF NOT EXISTS notifications (
          id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
          type VARCHAR(50) NOT NULL,
          user_id UUID,
          vehicle_id UUID,
          message TEXT NOT NULL,
          is_read BOOLEAN DEFAULT FALSE,
          created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
          updated_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
        );
      `);
      console.log('Created notifications table');
    } catch (error) {
      console.error('Error creating notifications table:', error);
      return { success: false, error };
    }
    
    // Create system_logs table
    console.log('Creating system_logs table...');
    try {
      await serviceSupabase.sql(`
        CREATE TABLE IF NOT EXISTS system_logs (
          id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
          user_id UUID,
          action VARCHAR(100) NOT NULL,
          details JSONB,
          ip_address VARCHAR(45),
          created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
        );
      `);
      console.log('Created system_logs table');
    } catch (error) {
      console.error('Error creating system_logs table:', error);
      return { success: false, error };
    }
    
    console.log('Database schema creation completed successfully!');
    return { success: true, message: 'Database schema creation completed successfully!' };
  } catch (error) {
    console.error('Error creating database schema:', error);
    return { success: false, error: error.message };
  }
}

// Execute the schema creation
createSchema()
  .then(result => {
    console.log('Schema creation result:', result);
    process.exit(result.success ? 0 : 1);
  })
  .catch(error => {
    console.error('Unhandled error during schema creation:', error);
    process.exit(1);
  });
