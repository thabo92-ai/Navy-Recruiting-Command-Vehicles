// This script tests the Supabase setup and API functions
import { setupDatabase } from '../lib/supabase-setup';
import { 
  userAPI, 
  vehicleAPI, 
  checkoutAPI, 
  checkinAPI, 
  maintenanceAPI, 
  notificationAPI, 
  systemLogAPI 
} from '../lib/api';

async function testSupabaseSetup() {
  console.log('Testing Supabase setup...');
  
  try {
    // Setup database
    console.log('Setting up database...');
    const setupResult = await setupDatabase();
    console.log('Database setup result:', setupResult);
    
    if (!setupResult.success) {
      console.error('Database setup failed:', setupResult.error);
      return;
    }
    
    // Test user API
    console.log('\nTesting user API...');
    const adminUser = await userAPI.createUser({
      email: 'admin@navy.mil',
      full_name: 'Admin User',
      rank: 'Commander',
      phone: '555-123-4567',
      is_admin: true
    });
    console.log('Created admin user:', adminUser);
    
    const standardUser = await userAPI.createUser({
      email: 'recruiter@navy.mil',
      full_name: 'Navy Recruiter',
      rank: 'Petty Officer',
      phone: '555-987-6543',
      is_admin: false
    });
    console.log('Created standard user:', standardUser);
    
    const allUsers = await userAPI.getAllUsers();
    console.log(`Retrieved ${allUsers.length} users`);
    
    // Test vehicle API
    console.log('\nTesting vehicle API...');
    const vehicle1 = await vehicleAPI.createVehicle({
      make: 'Ford',
      model: 'Explorer',
      year: 2023,
      color: 'Navy Blue',
      license_plate: 'NAVY-001',
      vin: '1FMSK8DH3PGB12345',
      current_mileage: 5000,
      fuel_capacity: 18.6,
      status: 'available',
      notes: 'Primary recruiting vehicle'
    });
    console.log('Created vehicle 1:', vehicle1);
    
    const vehicle2 = await vehicleAPI.createVehicle({
      make: 'Chevrolet',
      model: 'Tahoe',
      year: 2022,
      color: 'Black',
      license_plate: 'NAVY-002',
      vin: '1GNSKCKD2NR123456',
      current_mileage: 8500,
      fuel_capacity: 24.0,
      status: 'available',
      notes: 'Secondary recruiting vehicle'
    });
    console.log('Created vehicle 2:', vehicle2);
    
    const allVehicles = await vehicleAPI.getAllVehicles();
    console.log(`Retrieved ${allVehicles.length} vehicles`);
    
    // Test checkout API
    console.log('\nTesting checkout API...');
    const checkout = await checkoutAPI.createCheckout({
      vehicle_id: vehicle1.id,
      user_id: standardUser.id,
      expected_return_time: new Date(Date.now() + 86400000).toISOString(), // 24 hours from now
      destination: 'Local High School',
      purpose: 'Recruiting Event',
      starting_mileage: 5000,
      starting_fuel_level: 0.75,
      condition_notes: 'Vehicle in good condition',
      condition_photos: { urls: [] }
    });
    console.log('Created checkout:', checkout);
    
    const activeCheckouts = await checkoutAPI.getActiveCheckouts();
    console.log(`Retrieved ${activeCheckouts.length} active checkouts`);
    
    // Test checkin API
    console.log('\nTesting checkin API...');
    const checkin = await checkinAPI.createCheckin({
      checkout_id: checkout.id,
      ending_mileage: 5150,
      ending_fuel_level: 0.5,
      condition_notes: 'Vehicle returned in good condition',
      condition_photos: { urls: [] },
      maintenance_issues: 'None'
    });
    console.log('Created checkin:', checkin);
    
    // Test maintenance API
    console.log('\nTesting maintenance API...');
    const maintenance = await maintenanceAPI.createMaintenanceRecord({
      vehicle_id: vehicle1.id,
      maintenance_type: 'Oil Change',
      description: 'Regular oil change and inspection',
      mileage_at_maintenance: 5150,
      maintenance_date: new Date().toISOString().split('T')[0],
      cost: 45.99,
      performed_by: 'Navy Auto Shop',
      notes: 'Next service due at 10,000 miles'
    });
    console.log('Created maintenance record:', maintenance);
    
    // Test notification API
    console.log('\nTesting notification API...');
    const notification = await notificationAPI.createNotification({
      type: 'maintenance_reminder',
      user_id: adminUser.id,
      vehicle_id: vehicle1.id,
      message: 'Vehicle NAVY-001 is due for maintenance at 10,000 miles'
    });
    console.log('Created notification:', notification);
    
    // Test system log API
    console.log('\nTesting system log API...');
    const systemLog = await systemLogAPI.createSystemLog({
      user_id: adminUser.id,
      action: 'SYSTEM_TEST',
      details: { test: 'Supabase integration test', timestamp: new Date().toISOString() },
      ip_address: '127.0.0.1'
    });
    console.log('Created system log:', systemLog);
    
    console.log('\nAll tests completed successfully!');
    return { success: true };
  } catch (error) {
    console.error('Error during Supabase testing:', error);
    return { success: false, error: error.message };
  }
}

// Execute the test
testSupabaseSetup()
  .then(result => {
    console.log('Test result:', result);
    process.exit(result.success ? 0 : 1);
  })
  .catch(error => {
    console.error('Unhandled error during testing:', error);
    process.exit(1);
  });
