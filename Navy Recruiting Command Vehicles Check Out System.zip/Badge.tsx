import React from 'react';

interface BadgeProps {
  status: 'available' | 'checked_out' | 'maintenance' | 'out_of_service';
  className?: string;
}

const Badge: React.FC<BadgeProps> = ({ status, className = '' }) => {
  const statusClasses = {
    available: 'badge-available',
    checked_out: 'badge-checked-out',
    maintenance: 'badge-maintenance',
    out_of_service: 'badge-out-of-service',
  };

  const statusLabels = {
    available: 'Available',
    checked_out: 'Checked Out',
    maintenance: 'Maintenance',
    out_of_service: 'Out of Service',
  };

  return (
    <span className={`${statusClasses[status]} ${className}`}>
      {statusLabels[status]}
    </span>
  );
};

export default Badge;
