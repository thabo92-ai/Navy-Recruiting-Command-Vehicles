import React from 'react';
import Layout from '@/components/layout/Layout';
import Card from '@/components/ui/Card';
import Button from '@/components/ui/Button';
import Badge from '@/components/ui/Badge';

const Dashboard = () => {
  // Mock data for dashboard
  const stats = [
    { label: 'Total Vehicles', value: 12 },
    { label: 'Available', value: 8 },
    { label: 'Checked Out', value: 3 },
    { label: 'In Maintenance', value: 1 }
  ];

  const recentCheckouts = [
    { id: 1, vehicle: 'Ford Explorer (NAVY-001)', user: 'John Smith', checkoutTime: '2025-03-30 09:15', expectedReturn: '2025-03-31 17:00' },
    { id: 2, vehicle: 'Chevrolet Tahoe (NAVY-002)', user: 'Sarah Johnson', checkoutTime: '2025-03-30 10:30', expectedReturn: '2025-04-01 12:00' },
    { id: 3, vehicle: 'Dodge Charger (NAVY-003)', user: 'Michael Brown', checkoutTime: '2025-03-31 08:00', expectedReturn: '2025-03-31 16:00' }
  ];

  const maintenanceAlerts = [
    { id: 1, vehicle: 'Ford Explorer (NAVY-001)', issue: 'Oil change due', mileage: 5000 },
    { id: 2, vehicle: 'Chevrolet Tahoe (NAVY-002)', issue: 'Tire rotation needed', mileage: 8500 }
  ];

  return (
    <Layout>
      <h1 className="page-title">Dashboard</h1>
      
      {/* Stats Cards */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-8">
        {stats.map((stat, index) => (
          <Card key={index} className="text-center">
            <h2 className="text-2xl font-bold text-[#FFD700]">{stat.value}</h2>
            <p className="text-[#FFFFFF]">{stat.label}</p>
          </Card>
        ))}
      </div>
      
      {/* Quick Actions */}
      <Card title="Quick Actions" className="mb-8">
        <div className="flex flex-wrap gap-4">
          <Button>Check Out Vehicle</Button>
          <Button variant="secondary">Check In Vehicle</Button>
          <Button>Add New Vehicle</Button>
          <Button variant="danger">Report Issue</Button>
        </div>
      </Card>
      
      {/* Recent Checkouts */}
      <Card title="Recent Checkouts" className="mb-8">
        <div className="overflow-x-auto">
          <table className="min-w-full">
            <thead className="bg-[#000080] text-white">
              <tr>
                <th className="py-2 px-4 text-left">Vehicle</th>
                <th className="py-2 px-4 text-left">User</th>
                <th className="py-2 px-4 text-left">Checkout Time</th>
                <th className="py-2 px-4 text-left">Expected Return</th>
                <th className="py-2 px-4 text-left">Actions</th>
              </tr>
            </thead>
            <tbody>
              {recentCheckouts.map((checkout) => (
                <tr key={checkout.id} className="border-b border-[#000080]">
                  <td className="py-2 px-4">{checkout.vehicle}</td>
                  <td className="py-2 px-4">{checkout.user}</td>
                  <td className="py-2 px-4">{checkout.checkoutTime}</td>
                  <td className="py-2 px-4">{checkout.expectedReturn}</td>
                  <td className="py-2 px-4">
                    <Button size="sm">Check In</Button>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </Card>
      
      {/* Maintenance Alerts */}
      <Card title="Maintenance Alerts" className="mb-8">
        <div className="overflow-x-auto">
          <table className="min-w-full">
            <thead className="bg-[#000080] text-white">
              <tr>
                <th className="py-2 px-4 text-left">Vehicle</th>
                <th className="py-2 px-4 text-left">Issue</th>
                <th className="py-2 px-4 text-left">Current Mileage</th>
                <th className="py-2 px-4 text-left">Actions</th>
              </tr>
            </thead>
            <tbody>
              {maintenanceAlerts.map((alert) => (
                <tr key={alert.id} className="border-b border-[#000080]">
                  <td className="py-2 px-4">{alert.vehicle}</td>
                  <td className="py-2 px-4">{alert.issue}</td>
                  <td className="py-2 px-4">{alert.mileage} miles</td>
                  <td className="py-2 px-4">
                    <Button size="sm" variant="secondary">Schedule</Button>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </Card>
      
      {/* Vehicle Status */}
      <Card title="Vehicle Status Overview">
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
          <div className="p-4 border border-[#000080] rounded">
            <h3 className="font-bold mb-2">Ford Explorer</h3>
            <p className="text-sm mb-1">License: NAVY-001</p>
            <p className="text-sm mb-1">Mileage: 5,000 mi</p>
            <p className="text-sm mb-2">Last Service: 2025-02-15</p>
            <Badge status="available" />
          </div>
          <div className="p-4 border border-[#000080] rounded">
            <h3 className="font-bold mb-2">Chevrolet Tahoe</h3>
            <p className="text-sm mb-1">License: NAVY-002</p>
            <p className="text-sm mb-1">Mileage: 8,500 mi</p>
            <p className="text-sm mb-2">Last Service: 2025-01-20</p>
            <Badge status="checked_out" />
          </div>
          <div className="p-4 border border-[#000080] rounded">
            <h3 className="font-bold mb-2">Dodge Charger</h3>
            <p className="text-sm mb-1">License: NAVY-003</p>
            <p className="text-sm mb-1">Mileage: 3,200 mi</p>
            <p className="text-sm mb-2">Last Service: 2025-03-05</p>
            <Badge status="checked_out" />
          </div>
          <div className="p-4 border border-[#000080] rounded">
            <h3 className="font-bold mb-2">Toyota Camry</h3>
            <p className="text-sm mb-1">License: NAVY-004</p>
            <p className="text-sm mb-1">Mileage: 12,300 mi</p>
            <p className="text-sm mb-2">Last Service: 2025-02-28</p>
            <Badge status="maintenance" />
          </div>
        </div>
      </Card>
    </Layout>
  );
};

export default Dashboard;
