import React from 'react';

interface TableProps {
  headers: string[];
  data: any[];
  renderRow: (item: any, index: number) => React.ReactNode;
  className?: string;
}

const Table: React.FC<TableProps> = ({
  headers,
  data,
  renderRow,
  className = '',
}) => {
  return (
    <div className={`table-container ${className}`}>
      <table className="min-w-full divide-y divide-[#000080]">
        <thead className="table-header">
          <tr>
            {headers.map((header, index) => (
              <th
                key={index}
                scope="col"
                className="table-cell text-left"
              >
                {header}
              </th>
            ))}
          </tr>
        </thead>
        <tbody className="divide-y divide-[#000080]">
          {data.length > 0 ? (
            data.map((item, index) => renderRow(item, index))
          ) : (
            <tr>
              <td
                colSpan={headers.length}
                className="table-cell text-center py-8"
              >
                No data available
              </td>
            </tr>
          )}
        </tbody>
      </table>
    </div>
  );
};

export default Table;
