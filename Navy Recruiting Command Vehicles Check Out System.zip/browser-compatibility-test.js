// This script helps test browser compatibility by checking for features used in the application
// Run this in each target browser's console to identify potential compatibility issues

(function() {
  console.log('Running browser compatibility test...');
  
  const results = {
    browser: {
      userAgent: navigator.userAgent,
      vendor: navigator.vendor,
      platform: navigator.platform
    },
    features: {},
    apis: {},
    storage: {},
    display: {}
  };
  
  // Check core JavaScript features
  try {
    results.features.arrowFunctions = eval('(() => true)()');
  } catch (e) {
    results.features.arrowFunctions = false;
  }
  
  try {
    results.features.promises = typeof Promise !== 'undefined';
  } catch (e) {
    results.features.promises = false;
  }
  
  try {
    results.features.asyncAwait = eval('(async function() { return await Promise.resolve(true); })()') instanceof Promise;
  } catch (e) {
    results.features.asyncAwait = false;
  }
  
  try {
    results.features.destructuring = eval('(({a}) => a)({a: true})');
  } catch (e) {
    results.features.destructuring = false;
  }
  
  // Check Web APIs
  results.apis.serviceWorker = 'serviceWorker' in navigator;
  results.apis.geolocation = 'geolocation' in navigator;
  results.apis.webCrypto = 'crypto' in window && 'subtle' in window.crypto;
  results.apis.fetch = 'fetch' in window;
  results.apis.webShare = 'share' in navigator;
  
  // Check camera access for QR code scanning
  results.apis.mediaDevices = 'mediaDevices' in navigator && 'getUserMedia' in navigator.mediaDevices;
  
  // Check storage APIs
  results.storage.localStorage = 'localStorage' in window;
  results.storage.sessionStorage = 'sessionStorage' in window;
  results.storage.indexedDB = 'indexedDB' in window;
  
  // Check display features
  results.display.grid = CSS.supports('display', 'grid');
  results.display.flexbox = CSS.supports('display', 'flex');
  results.display.customProperties = CSS.supports('--custom-property', 'value');
  
  // Check for PWA support
  results.pwa = {
    serviceWorkerRegistration: 'serviceWorker' in navigator,
    caches: 'caches' in window,
    pushManager: 'PushManager' in window,
    beforeInstallPrompt: 'BeforeInstallPromptEvent' in window
  };
  
  // Check for offline capability support
  results.offline = {
    onlineOfflineEvents: 'onLine' in navigator,
    cacheStorage: 'caches' in window,
    backgroundSync: 'serviceWorker' in navigator && 'SyncManager' in window
  };
  
  // Check for file APIs (for Excel export)
  results.fileApis = {
    blob: 'Blob' in window,
    file: 'File' in window,
    fileReader: 'FileReader' in window,
    url: 'URL' in window && 'createObjectURL' in URL
  };
  
  // Identify potential issues
  const issues = [];
  
  // Check for critical features
  if (!results.features.promises || !results.features.asyncAwait) {
    issues.push('CRITICAL: Modern JavaScript features not supported. Application will not function correctly.');
  }
  
  if (!results.apis.serviceWorker) {
    issues.push('HIGH: Service Workers not supported. Offline functionality will not work.');
  }
  
  if (!results.apis.mediaDevices) {
    issues.push('HIGH: Camera access not supported. QR code scanning will not work.');
  }
  
  if (!results.storage.localStorage) {
    issues.push('HIGH: LocalStorage not supported. User sessions and offline data storage will not work.');
  }
  
  if (!results.display.flexbox) {
    issues.push('MEDIUM: Flexbox not supported. UI layout will be broken.');
  }
  
  if (!results.fileApis.blob || !results.fileApis.url) {
    issues.push('MEDIUM: File APIs not fully supported. Excel export may not work correctly.');
  }
  
  // Output results
  console.log('Browser Information:', results.browser);
  console.log('Feature Support:', results);
  
  if (issues.length > 0) {
    console.warn('Compatibility Issues Detected:');
    issues.forEach(issue => console.warn('- ' + issue));
  } else {
    console.log('No compatibility issues detected. Browser should support all required features.');
  }
  
  return {
    results,
    issues
  };
})();
