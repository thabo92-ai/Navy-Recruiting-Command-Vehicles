// iOS compatibility enhancements for Navy Vehicle Management System

// Function to detect iOS device
export const isIOS = () => {
  if (typeof window === 'undefined') return false;
  
  const userAgent = window.navigator.userAgent.toLowerCase();
  return /iphone|ipad|ipod/.test(userAgent);
};

// Function to detect iOS version
export const getIOSVersion = () => {
  if (!isIOS()) return null;
  
  const userAgent = window.navigator.userAgent;
  const match = userAgent.match(/OS (\d+)_(\d+)_?(\d+)?/);
  
  if (match) {
    return {
      major: parseInt(match[1], 10),
      minor: parseInt(match[2], 10),
      patch: parseInt(match[3] || 0, 10)
    };
  }
  
  return null;
};

// Apply iOS-specific fixes
export const applyIOSFixes = () => {
  if (!isIOS()) return;
  
  // Fix for 100vh issue on iOS
  const fixIOSViewportHeight = () => {
    const vh = window.innerHeight * 0.01;
    document.documentElement.style.setProperty('--vh', `${vh}px`);
  };
  
  // Fix for input focus issues on iOS
  const fixIOSInputFocus = () => {
    const inputs = document.querySelectorAll('input, textarea, select');
    inputs.forEach(input => {
      input.addEventListener('focus', () => {
        document.body.classList.add('input-focused');
      });
      
      input.addEventListener('blur', () => {
        document.body.classList.remove('input-focused');
      });
    });
  };
  
  // Fix for iOS scroll bounce
  const fixIOSScrollBounce = () => {
    document.body.style.overflow = 'hidden';
    document.body.style.position = 'fixed';
    document.body.style.height = '100%';
    document.body.style.width = '100%';
    
    // Allow scrolling in specific containers
    const scrollContainers = document.querySelectorAll('.scroll-container');
    scrollContainers.forEach(container => {
      container.style.overflow = 'auto';
      container.style.WebkitOverflowScrolling = 'touch';
    });
  };
  
  // Fix for iOS PWA status bar
  const fixIOSStatusBar = () => {
    const metaStatusBar = document.querySelector('meta[name="apple-mobile-web-app-status-bar-style"]');
    if (!metaStatusBar) {
      const meta = document.createElement('meta');
      meta.name = 'apple-mobile-web-app-status-bar-style';
      meta.content = 'black-translucent';
      document.head.appendChild(meta);
    }
  };
  
  // Apply all fixes
  window.addEventListener('resize', fixIOSViewportHeight);
  fixIOSViewportHeight();
  fixIOSInputFocus();
  
  // Only apply scroll bounce fix if in standalone mode (PWA)
  if (window.navigator.standalone) {
    fixIOSScrollBounce();
  }
  
  fixIOSStatusBar();
  
  // Return cleanup function
  return () => {
    window.removeEventListener('resize', fixIOSViewportHeight);
  };
};

// Add iOS-specific meta tags
export const addIOSMetaTags = () => {
  if (typeof document === 'undefined') return;
  
  const metaTags = [
    { name: 'apple-mobile-web-app-capable', content: 'yes' },
    { name: 'apple-mobile-web-app-status-bar-style', content: 'black-translucent' },
    { name: 'apple-mobile-web-app-title', content: 'NTAG PNW Vehicle Log' }
  ];
  
  metaTags.forEach(tag => {
    if (!document.querySelector(`meta[name="${tag.name}"]`)) {
      const meta = document.createElement('meta');
      meta.name = tag.name;
      meta.content = tag.content;
      document.head.appendChild(meta);
    }
  });
};

// Add iOS splash screen images
export const addIOSSplashScreens = () => {
  if (typeof document === 'undefined') return;
  
  const splashScreens = [
    { href: '/splash/iphone5_splash.png', media: '(device-width: 320px) and (device-height: 568px) and (-webkit-device-pixel-ratio: 2)' },
    { href: '/splash/iphone6_splash.png', media: '(device-width: 375px) and (device-height: 667px) and (-webkit-device-pixel-ratio: 2)' },
    { href: '/splash/iphoneplus_splash.png', media: '(device-width: 621px) and (device-height: 1104px) and (-webkit-device-pixel-ratio: 3)' },
    { href: '/splash/iphonex_splash.png', media: '(device-width: 375px) and (device-height: 812px) and (-webkit-device-pixel-ratio: 3)' },
    { href: '/splash/iphonexr_splash.png', media: '(device-width: 414px) and (device-height: 896px) and (-webkit-device-pixel-ratio: 2)' },
    { href: '/splash/iphonexsmax_splash.png', media: '(device-width: 414px) and (device-height: 896px) and (-webkit-device-pixel-ratio: 3)' },
    { href: '/splash/ipad_splash.png', media: '(device-width: 768px) and (device-height: 1024px) and (-webkit-device-pixel-ratio: 2)' },
    { href: '/splash/ipadpro1_splash.png', media: '(device-width: 834px) and (device-height: 1112px) and (-webkit-device-pixel-ratio: 2)' },
    { href: '/splash/ipadpro2_splash.png', media: '(device-width: 834px) and (device-height: 1194px) and (-webkit-device-pixel-ratio: 2)' },
    { href: '/splash/ipadpro3_splash.png', media: '(device-width: 1024px) and (device-height: 1366px) and (-webkit-device-pixel-ratio: 2)' }
  ];
  
  splashScreens.forEach(screen => {
    if (!document.querySelector(`link[rel="apple-touch-startup-image"][media="${screen.media}"]`)) {
      const link = document.createElement('link');
      link.rel = 'apple-touch-startup-image';
      link.href = screen.href;
      link.media = screen.media;
      document.head.appendChild(link);
    }
  });
};

// Initialize all iOS compatibility features
export const initIOSCompatibility = () => {
  if (typeof window === 'undefined') return;
  
  if (isIOS()) {
    addIOSMetaTags();
    addIOSSplashScreens();
    applyIOSFixes();
    
    console.log('iOS compatibility features initialized');
  }
};
