// This script tests the Supabase connection and API functions
const { createClient } = require('@supabase/supabase-js');

const supabaseUrl = 'https://tgzyqycyoyzrbgjvzvzx.supabase.co';
const supabaseAnonKey = 'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6InRnenlxeWN5b3l6cmJnanZ6dnp4Iiwicm9sZSI6ImFub24iLCJpYXQiOjE3NDMzNzU2MDksImV4cCI6MjA1ODk1MTYwOX0.smPHsTDorXUKdOYxUVxQV8h2UEx_mDP-rM5Vz9MW8t8';

// Create Supabase client
const supabase = createClient(supabaseUrl, supabaseAnonKey);

async function testSupabaseConnection() {
  console.log('Testing Supabase connection...');
  
  try {
    // Test connection by getting Supabase health
    const { data, error } = await supabase.from('users').select('count').limit(0);
    
    if (error && error.code === '42P01') {
      console.log('Users table does not exist yet, but connection to Supabase is working');
    } else if (error) {
      console.error('Error connecting to Supabase:', error);
      return { success: false, error: error.message };
    } else {
      console.log('Successfully connected to Supabase');
    }
    
    // Test creating a user
    console.log('\nTesting user creation...');
    const { data: userData, error: userError } = await supabase
      .from('users')
      .upsert({
        email: 'test@navy.mil',
        full_name: 'Test User',
        rank: 'Ensign',
        phone: '555-555-5555',
        is_admin: false
      }, { onConflict: 'email' })
      .select();
    
    if (userError) {
      console.log('Note: Could not create user. If table does not exist, this is expected:', userError);
    } else {
      console.log('Successfully created/updated user:', userData);
    }
    
    // Test creating a vehicle
    console.log('\nTesting vehicle creation...');
    const { data: vehicleData, error: vehicleError } = await supabase
      .from('vehicles')
      .upsert({
        make: 'Test',
        model: 'Vehicle',
        year: 2025,
        color: 'Navy Blue',
        license_plate: 'TEST-001',
        vin: 'TEST12345678901234',
        current_mileage: 0,
        fuel_capacity: 15.0,
        status: 'available',
        notes: 'Test vehicle'
      }, { onConflict: 'license_plate' })
      .select();
    
    if (vehicleError) {
      console.log('Note: Could not create vehicle. If table does not exist, this is expected:', vehicleError);
    } else {
      console.log('Successfully created/updated vehicle:', vehicleData);
    }
    
    console.log('\nSupabase connection test completed successfully!');
    return { success: true, message: 'Supabase connection test completed successfully!' };
  } catch (error) {
    console.error('Error during Supabase testing:', error);
    return { success: false, error: error.message };
  }
}

// Execute the test
testSupabaseConnection()
  .then(result => {
    console.log('Test result:', result);
    process.exit(result.success ? 0 : 1);
  })
  .catch(error => {
    console.error('Unhandled error during testing:', error);
    process.exit(1);
  });
