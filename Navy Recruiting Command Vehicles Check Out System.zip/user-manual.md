# Navy Recruiting Command Vehicle Management System
# User Manual

## Table of Contents
1. [Introduction](#introduction)
2. [Getting Started](#getting-started)
3. [Dashboard](#dashboard)
4. [Vehicle Management](#vehicle-management)
5. [Vehicle Checkout Process](#vehicle-checkout-process)
6. [Vehicle Check-in Process](#vehicle-check-in-process)
7. [QR Code System](#qr-code-system)
8. [Maintenance Records](#maintenance-records)
9. [User Management](#user-management)
10. [Reports and Exports](#reports-and-exports)
11. [Settings](#settings)
12. [Offline Functionality](#offline-functionality)
13. [Troubleshooting](#troubleshooting)
14. [FAQ](#faq)

## Introduction

The Navy Recruiting Command Vehicle Management System is a premium web-based application designed to streamline the management of the Navy Recruiting Command's vehicle fleet. This comprehensive system allows for efficient tracking, checkout, and check-in of vehicles, maintenance scheduling, and reporting.

### System Overview

The system provides the following key features:
- Vehicle inventory management
- Streamlined vehicle checkout and check-in processes
- QR code integration for quick vehicle identification
- Maintenance tracking and scheduling
- User management with role-based access control
- Comprehensive reporting and Excel export capabilities
- Offline functionality for field operations
- Cross-platform compatibility (desktop, iOS, Android)

### User Roles

The system supports two primary user roles:

1. **Administrator**
   - Full access to all system features
   - User management capabilities
   - System configuration
   - Report generation
   - Vehicle fleet management

2. **Standard User**
   - Vehicle checkout and check-in
   - View available vehicles
   - Report maintenance issues
   - View personal checkout history

## Getting Started

### Accessing the System

The Navy Recruiting Command Vehicle Management System is a web-based application accessible via any modern web browser. For optimal performance, we recommend using the latest versions of Chrome, Firefox, Safari, or Edge.

1. Open your web browser
2. Navigate to the system URL provided by your administrator
3. You will be directed to the login page

### Logging In

1. On the login page, enter your assigned username and password
2. Click the "Sign In" button
3. If this is your first time logging in, you may be prompted to change your password

### Navigation

The system features a user-friendly navigation system:

- **Top Navigation Bar**: Contains the system logo, user profile menu, and notifications
- **Side Navigation Menu**: Provides access to all system modules
- **User Profile Menu**: Access to user settings, help, and logout options
- **Breadcrumb Navigation**: Shows your current location within the system

## Dashboard

The dashboard provides an at-a-glance overview of the vehicle fleet status and recent activity.

### Dashboard Components

1. **Fleet Overview**
   - Total number of vehicles
   - Available vehicles
   - Checked-out vehicles
   - Vehicles in maintenance

2. **Recent Activity**
   - Latest checkouts and check-ins
   - Recent maintenance reports
   - System notifications

3. **Quick Actions**
   - Checkout a vehicle
   - Check-in a vehicle
   - Report maintenance issue
   - Generate reports

4. **Vehicle Status Chart**
   - Visual representation of vehicle status distribution

## Vehicle Management

The Vehicle Management module allows administrators to manage the entire vehicle fleet.

### Viewing Vehicles

1. Navigate to "Vehicles" in the side menu
2. View the complete list of vehicles with status indicators
3. Use the search and filter options to find specific vehicles

### Adding a New Vehicle

Administrators can add new vehicles to the fleet:

1. Navigate to "Vehicles" in the side menu
2. Click the "Add Vehicle" button
3. Fill in the required information:
   - Make and model
   - Year
   - License plate number
   - VIN
   - Assigned location
   - Additional notes
4. Click "Save" to add the vehicle to the fleet

### Editing Vehicle Information

1. Navigate to "Vehicles" in the side menu
2. Find the vehicle you wish to edit
3. Click the "Edit" button (pencil icon)
4. Update the vehicle information
5. Click "Save" to apply changes

### Vehicle Details

Click on any vehicle to view detailed information:

- Vehicle specifications
- Current status
- Checkout history
- Maintenance history
- QR code for quick checkout

## Vehicle Checkout Process

The system provides a streamlined process for checking out vehicles.

### Standard Checkout Process

1. Navigate to "Checkout" in the side menu
2. Select a vehicle from the available vehicles list
   - Alternatively, scan the vehicle's QR code using the QR Scanner
3. Complete the checkout form:
   - Purpose of use
   - Expected return date/time
   - Starting mileage (verify the displayed value)
   - Fuel level (verify the displayed value)
   - Vehicle condition notes
4. Review the checkout information
5. Click "Confirm Checkout" to complete the process
6. You will receive a confirmation with checkout details

### Quick Checkout via QR Code

1. Navigate to "QR Code" → "Scanner" in the side menu
2. Scan the vehicle's QR code using your device's camera
3. The system will identify the vehicle and display its information
4. Click "Checkout Vehicle" to proceed to the checkout form
5. Complete the checkout process as described above

## Vehicle Check-in Process

When returning a vehicle, the check-in process records the vehicle's condition and usage details.

### Standard Check-in Process

1. Navigate to "Check-in" in the side menu
2. Select your active checkout from the list
   - Alternatively, scan the vehicle's QR code using the QR Scanner
3. Complete the check-in form:
   - Ending mileage
   - Fuel level
   - Vehicle condition
   - Any maintenance issues to report
   - Additional notes
4. Upload photos if there are any issues to document
5. Review the check-in information
6. Click "Confirm Check-in" to complete the process
7. You will receive a confirmation with check-in details

### Quick Check-in via QR Code

1. Navigate to "QR Code" → "Scanner" in the side menu
2. Scan the vehicle's QR code using your device's camera
3. The system will identify the vehicle and display its information
4. Click "Check-in Vehicle" to proceed to the check-in form
5. Complete the check-in process as described above

## QR Code System

The QR code system enables quick identification of vehicles and streamlines the checkout and check-in processes.

### Accessing the QR Code System

1. Navigate to "QR Code" in the side menu
2. Choose between "Generator" and "Scanner"

### Generating QR Codes

Administrators can generate QR codes for vehicles:

1. Navigate to "QR Code" → "Generator" in the side menu
2. Select a vehicle from the dropdown list
3. Adjust QR code settings if needed:
   - Size
   - Error correction level
4. Click "Generate QR Code"
5. Once generated, you can:
   - Download the QR code as an image
   - Print the QR code with vehicle information

### Scanning QR Codes

1. Navigate to "QR Code" → "Scanner" in the side menu
2. Allow camera access when prompted
3. Position the QR code within the scanning area
4. Once scanned, the system will:
   - Display vehicle information
   - Provide options to checkout or check-in the vehicle

### Printing and Placing QR Codes

For optimal use of the QR code system:

1. Print QR codes on durable material
2. Place QR codes in a consistent location in each vehicle
   - Recommended: Glove compartment or driver's side door pocket
3. Include brief instructions for scanning

## Maintenance Records

The Maintenance Records module tracks all vehicle maintenance activities.

### Viewing Maintenance Records

1. Navigate to "Maintenance" in the side menu
2. View the complete list of maintenance records
3. Use filters to sort by:
   - Vehicle
   - Maintenance type
   - Date range
   - Status

### Reporting Maintenance Issues

Users can report maintenance issues during check-in or separately:

1. Navigate to "Maintenance" in the side menu
2. Click "Report Issue"
3. Select the vehicle
4. Describe the issue in detail
5. Set priority level
6. Upload photos if available
7. Submit the report

### Scheduling Maintenance

Administrators can schedule maintenance for vehicles:

1. Navigate to "Maintenance" in the side menu
2. Click "Schedule Maintenance"
3. Select the vehicle
4. Choose maintenance type
5. Set scheduled date
6. Add notes for the maintenance provider
7. Save the scheduled maintenance

### Updating Maintenance Status

Administrators can update the status of maintenance records:

1. Navigate to "Maintenance" in the side menu
2. Find the maintenance record to update
3. Click "Update Status"
4. Select the new status:
   - Scheduled
   - In Progress
   - Completed
   - Cancelled
5. Add notes about the update
6. Save changes

## User Management

The User Management module allows administrators to manage system users.

### Viewing Users

1. Navigate to "Users" in the side menu
2. View the complete list of system users
3. Use search and filters to find specific users

### Adding New Users

Administrators can add new users to the system:

1. Navigate to "Users" in the side menu
2. Click "Add User"
3. Fill in the required information:
   - Full name
   - Email address
   - Phone number
   - User role (Administrator or Standard User)
   - Additional notes
4. Click "Create User"
5. The system will send an invitation email to the new user

### Editing User Information

1. Navigate to "Users" in the side menu
2. Find the user you wish to edit
3. Click the "Edit" button
4. Update the user information
5. Click "Save" to apply changes

### Deactivating Users

When a user no longer needs access to the system:

1. Navigate to "Users" in the side menu
2. Find the user you wish to deactivate
3. Click the "Deactivate" button
4. Confirm the deactivation
5. The user will no longer be able to access the system

## Reports and Exports

The system provides comprehensive reporting and data export capabilities.

### Available Reports

1. **Vehicle Usage Report**
   - Shows checkout frequency and duration for each vehicle
   - Helps identify underutilized or overused vehicles

2. **User Activity Report**
   - Tracks user checkout patterns
   - Identifies most active users

3. **Maintenance Report**
   - Lists all maintenance activities
   - Helps track maintenance costs and frequency

4. **Fuel Consumption Report**
   - Tracks fuel usage across the fleet
   - Identifies vehicles with unusual fuel consumption

### Generating Reports

1. Navigate to "Export" in the side menu
2. Select the report type
3. Set parameters:
   - Date range
   - Vehicles to include
   - Additional filters
4. Click "Generate Report"
5. View the report in the browser

### Exporting to Excel

All reports can be exported to Excel format:

1. Generate the desired report
2. Click "Export to Excel"
3. Choose export options:
   - Include all data
   - Include charts
   - Format options
4. Click "Download"
5. The Excel file will be downloaded to your device

### Scheduled Reports

Administrators can set up scheduled reports:

1. Navigate to "Export" in the side menu
2. Click "Schedule Report"
3. Select report type and parameters
4. Set schedule:
   - Daily, weekly, or monthly
   - Delivery time
   - Recipients
5. Save the scheduled report

## Settings

The Settings module allows administrators to configure system preferences.

### General Settings

1. Navigate to "Settings" in the side menu
2. In the General Settings section, configure:
   - System name
   - Organization name
   - Contact email
   - Default checkout duration
   - Approval requirements

### Notification Settings

Configure system notifications:

1. Navigate to "Settings" in the side menu
2. In the Notification Settings section, toggle:
   - Email notifications
   - Checkout reminders
   - Check-in reminders
   - Maintenance alerts
   - Admin reports
   - Daily summaries

### Display Settings

Customize the user interface:

1. Navigate to "Settings" in the side menu
2. In the Display Settings section, configure:
   - Dark/light mode
   - Compact view
   - Show/hide vehicle images
   - Default dashboard view
   - Date and time formats

## Offline Functionality

The system is designed to function even without an internet connection.

### How Offline Mode Works

1. When online, the system automatically caches essential data
2. If internet connection is lost, the system switches to offline mode
3. A notification appears indicating offline status
4. You can continue to perform most operations
5. When connection is restored, the system automatically syncs data

### Available Offline Features

The following features are available in offline mode:

- Viewing vehicle information
- Vehicle checkout process
- Vehicle check-in process
- QR code scanning
- Viewing recent activity

### Limitations in Offline Mode

Some features have limited functionality when offline:

- Cannot access complete historical data
- Cannot add new vehicles to the fleet
- Limited reporting capabilities
- Cannot modify system settings

### Data Synchronization

When internet connection is restored:

1. The system automatically detects the connection
2. A notification appears indicating sync is in progress
3. All offline actions are synchronized with the server
4. Any conflicts are flagged for resolution
5. A sync completion notification appears

## Troubleshooting

### Common Issues and Solutions

1. **Login Problems**
   - Ensure you're using the correct username and password
   - Check if Caps Lock is enabled
   - Try the "Forgot Password" option
   - Contact your administrator if problems persist

2. **QR Code Scanning Issues**
   - Ensure good lighting conditions
   - Hold the device steady
   - Make sure the QR code is clean and undamaged
   - Try adjusting the distance from the code

3. **Offline Mode Not Working**
   - Ensure you've previously logged in while online
   - Check if your browser supports offline functionality
   - Clear browser cache and try again
   - Contact technical support if problems persist

4. **Export Problems**
   - Check your device's storage space
   - Ensure you have permission to download files
   - Try a different browser
   - Reduce the date range to create a smaller file

### Error Messages

Common error messages and their meanings:

- **"Network Error"**: The system cannot connect to the server
- **"Unauthorized Access"**: You don't have permission for the requested action
- **"Invalid Input"**: The information entered doesn't meet requirements
- **"Session Expired"**: Your login session has timed out, please log in again

### Getting Help

If you encounter issues not covered in this manual:

1. Check the FAQ section
2. Contact your system administrator
3. Use the "Help" option in the user profile menu
4. Email support at the address provided in the Settings page

## FAQ

### General Questions

**Q: How do I reset my password?**
A: Click the "Forgot Password" link on the login page and follow the instructions sent to your email.

**Q: Can I use the system on my mobile device?**
A: Yes, the system is fully responsive and works on smartphones and tablets. For the best experience on iOS devices, we recommend adding it to your home screen.

**Q: How do I report bugs or suggest features?**
A: Contact your system administrator or use the feedback form in the Help section.

### Vehicle Checkout Questions

**Q: What if the vehicle condition doesn't match what's in the system?**
A: Document the discrepancy during checkout, take photos if possible, and notify your administrator.

**Q: Can I extend my checkout period?**
A: Yes, if the vehicle is not reserved by someone else. Use the "Extend Checkout" option in your active checkouts.

**Q: What happens if I return a vehicle late?**
A: The system will flag the late return. Follow your organization's policy regarding late returns.

### QR Code Questio
(Content truncated due to size limit. Use line ranges to read in chunks)