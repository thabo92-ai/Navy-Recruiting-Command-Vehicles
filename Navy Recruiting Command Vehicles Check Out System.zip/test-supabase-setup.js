// This script tests the Supabase setup and API functions
const { createClient } = require('@supabase/supabase-js');

const supabaseUrl = 'https://tgzyqycyoyzrbgjvzvzx.supabase.co';
const supabaseAnonKey = 'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6InRnenlxeWN5b3l6cmJnanZ6dnp4Iiwicm9sZSI6ImFub24iLCJpYXQiOjE3NDMzNzU2MDksImV4cCI6MjA1ODk1MTYwOX0.smPHsTDorXUKdOYxUVxQV8h2UEx_mDP-rM5Vz9MW8t8';
const supabaseServiceKey = 'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6InRnenlxeWN5b3l6cmJnanZ6dnp4Iiwicm9sZSI6InNlcnZpY2Vfcm9sZSIsImlhdCI6MTc0MzM3NTYwOSwiZXhwIjoyMDU4OTUxNjA5fQ.eMuA61Fk-5yPBVc0hm9nSOoQbo-qa5F90pYLlrF2mPw';

// Create Supabase clients
const supabase = createClient(supabaseUrl, supabaseAnonKey);
const serviceSupabase = createClient(supabaseUrl, supabaseServiceKey);

async function setupDatabase() {
  console.log('Starting database setup...');
  
  try {
    // Test user creation
    console.log('Testing user creation...');
    try {
      const { data: adminUser, error: adminError } = await serviceSupabase
        .from('users')
        .insert([{
          email: 'admin@navy.mil',
          full_name: 'Admin User',
          rank: 'Commander',
          phone: '555-123-4567',
          is_admin: true
        }])
        .select();
      
      if (adminError) {
        console.error('Error creating admin user:', adminError);
      } else {
        console.log('Created admin user:', adminUser);
      }
    } catch (error) {
      console.log('Note: Could not create user, table might not exist yet');
    }
    
    // Test vehicle creation
    console.log('Testing vehicle creation...');
    try {
      const { data: vehicle, error: vehicleError } = await serviceSupabase
        .from('vehicles')
        .insert([{
          make: 'Ford',
          model: 'Explorer',
          year: 2023,
          color: 'Navy Blue',
          license_plate: 'NAVY-001',
          vin: '1FMSK8DH3PGB12345',
          current_mileage: 5000,
          fuel_capacity: 18.6,
          status: 'available',
          notes: 'Primary recruiting vehicle'
        }])
        .select();
      
      if (vehicleError) {
        console.error('Error creating vehicle:', vehicleError);
      } else {
        console.log('Created vehicle:', vehicle);
      }
    } catch (error) {
      console.log('Note: Could not create vehicle, table might not exist yet');
    }
    
    // Test getting users
    console.log('Testing getting users...');
    try {
      const { data: users, error: usersError } = await serviceSupabase
        .from('users')
        .select('*');
      
      if (usersError) {
        console.error('Error getting users:', usersError);
      } else {
        console.log(`Retrieved ${users.length} users`);
      }
    } catch (error) {
      console.log('Note: Could not get users, table might not exist yet');
    }
    
    // Test getting vehicles
    console.log('Testing getting vehicles...');
    try {
      const { data: vehicles, error: vehiclesError } = await serviceSupabase
        .from('vehicles')
        .select('*');
      
      if (vehiclesError) {
        console.error('Error getting vehicles:', vehiclesError);
      } else {
        console.log(`Retrieved ${vehicles.length} vehicles`);
      }
    } catch (error) {
      console.log('Note: Could not get vehicles, table might not exist yet');
    }
    
    console.log('Supabase connection test completed!');
    return { success: true, message: 'Supabase connection test completed!' };
  } catch (error) {
    console.error('Error during Supabase testing:', error);
    return { success: false, error: error.message };
  }
}

// Execute the setup
setupDatabase()
  .then(result => {
    console.log('Test result:', result);
    process.exit(result.success ? 0 : 1);
  })
  .catch(error => {
    console.error('Unhandled error during testing:', error);
    process.exit(1);
  });
