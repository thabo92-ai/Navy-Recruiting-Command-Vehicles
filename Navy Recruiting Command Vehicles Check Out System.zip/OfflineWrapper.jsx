import { useEffect } from 'react';
import { OfflineStorageProvider } from '@/lib/offlineStorage';
import { useServiceWorker } from '@/lib/serviceWorker';

const OfflineStatusBar = () => {
  const { isOffline, isUpdateAvailable, updateServiceWorker } = useServiceWorker();

  return (
    <>
      {isOffline && (
        <div className="fixed bottom-0 left-0 right-0 bg-red-600 text-white p-2 text-center z-50">
          You are currently offline. Some features may be limited.
        </div>
      )}
      
      {isUpdateAvailable && (
        <div className="fixed bottom-0 left-0 right-0 bg-[#FFD700] text-[#050A30] p-2 text-center z-50 flex justify-center items-center">
          <span className="mr-2">A new version is available!</span>
          <button 
            onClick={updateServiceWorker}
            className="bg-[#000080] text-white px-4 py-1 rounded text-sm"
          >
            Update Now
          </button>
        </div>
      )}
    </>
  );
};

export function OfflineWrapper({ children }) {
  return (
    <OfflineStorageProvider>
      <OfflineStatusBar />
      {children}
    </OfflineStorageProvider>
  );
}
