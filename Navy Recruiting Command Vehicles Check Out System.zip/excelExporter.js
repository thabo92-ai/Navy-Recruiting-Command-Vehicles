import * as XLSX from 'xlsx';

/**
 * Utility class for exporting data to Excel format
 */
export class ExcelExporter {
  /**
   * Export data to Excel file and trigger download
   * 
   * @param {Array} data - Array of objects to export
   * @param {string} filename - Name of the file to download (without extension)
   * @param {string} sheetName - Name of the worksheet
   * @param {Array} columns - Optional array of column definitions { header: 'Display Name', key: 'dataKey' }
   * @returns {void}
   */
  static exportToExcel(data, filename, sheetName = 'Sheet1', columns = null) {
    try {
      // Create a new workbook
      const workbook = XLSX.utils.book_new();
      
      let worksheet;
      
      // If columns are specified, use them to format the data
      if (columns) {
        // Map the data to include only the specified columns
        const formattedData = data.map(item => {
          const newItem = {};
          columns.forEach(column => {
            newItem[column.header] = item[column.key];
          });
          return newItem;
        });
        
        // Create worksheet from the formatted data
        worksheet = XLSX.utils.json_to_sheet(formattedData);
      } else {
        // Create worksheet from the raw data
        worksheet = XLSX.utils.json_to_sheet(data);
      }
      
      // Add the worksheet to the workbook
      XLSX.utils.book_append_sheet(workbook, worksheet, sheetName);
      
      // Generate Excel file and trigger download
      XLSX.writeFile(workbook, `${filename}.xlsx`);
      
      return true;
    } catch (error) {
      console.error('Error exporting to Excel:', error);
      return false;
    }
  }
  
  /**
   * Export multiple datasets to Excel file with multiple sheets
   * 
   * @param {Array} sheets - Array of sheet definitions { name: 'SheetName', data: [], columns: [] }
   * @param {string} filename - Name of the file to download (without extension)
   * @returns {void}
   */
  static exportMultipleSheetsToExcel(sheets, filename) {
    try {
      // Create a new workbook
      const workbook = XLSX.utils.book_new();
      
      // Process each sheet
      sheets.forEach(sheet => {
        let worksheet;
        
        // If columns are specified, use them to format the data
        if (sheet.columns) {
          // Map the data to include only the specified columns
          const formattedData = sheet.data.map(item => {
            const newItem = {};
            sheet.columns.forEach(column => {
              newItem[column.header] = item[column.key];
            });
            return newItem;
          });
          
          // Create worksheet from the formatted data
          worksheet = XLSX.utils.json_to_sheet(formattedData);
        } else {
          // Create worksheet from the raw data
          worksheet = XLSX.utils.json_to_sheet(sheet.data);
        }
        
        // Add the worksheet to the workbook
        XLSX.utils.book_append_sheet(workbook, worksheet, sheet.name);
      });
      
      // Generate Excel file and trigger download
      XLSX.writeFile(workbook, `${filename}.xlsx`);
      
      return true;
    } catch (error) {
      console.error('Error exporting multiple sheets to Excel:', error);
      return false;
    }
  }
  
  /**
   * Generate Excel file from data and return as a blob
   * 
   * @param {Array} data - Array of objects to export
   * @param {string} sheetName - Name of the worksheet
   * @param {Array} columns - Optional array of column definitions { header: 'Display Name', key: 'dataKey' }
   * @returns {Blob} Excel file as blob
   */
  static generateExcelBlob(data, sheetName = 'Sheet1', columns = null) {
    try {
      // Create a new workbook
      const workbook = XLSX.utils.book_new();
      
      let worksheet;
      
      // If columns are specified, use them to format the data
      if (columns) {
        // Map the data to include only the specified columns
        const formattedData = data.map(item => {
          const newItem = {};
          columns.forEach(column => {
            newItem[column.header] = item[column.key];
          });
          return newItem;
        });
        
        // Create worksheet from the formatted data
        worksheet = XLSX.utils.json_to_sheet(formattedData);
      } else {
        // Create worksheet from the raw data
        worksheet = XLSX.utils.json_to_sheet(data);
      }
      
      // Add the worksheet to the workbook
      XLSX.utils.book_append_sheet(workbook, worksheet, sheetName);
      
      // Generate Excel file as array buffer
      const excelBuffer = XLSX.write(workbook, { bookType: 'xlsx', type: 'array' });
      
      // Convert array buffer to blob
      const blob = new Blob([excelBuffer], { type: 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet' });
      
      return blob;
    } catch (error) {
      console.error('Error generating Excel blob:', error);
      return null;
    }
  }
}
