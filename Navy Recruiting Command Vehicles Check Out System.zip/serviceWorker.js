import { useEffect, useState } from 'react';
import { Workbox } from 'workbox-window';

export function useServiceWorker() {
  const [isUpdateAvailable, setIsUpdateAvailable] = useState(false);
  const [registration, setRegistration] = useState(null);
  const [isOffline, setIsOffline] = useState(false);

  useEffect(() => {
    if (
      typeof window !== 'undefined' &&
      'serviceWorker' in navigator &&
      window.workbox !== undefined
    ) {
      // Check if we're online or offline
      setIsOffline(!navigator.onLine);
      window.addEventListener('online', () => setIsOffline(false));
      window.addEventListener('offline', () => setIsOffline(true));

      // Register the service worker
      const wb = new Workbox('/service-worker.js');

      // Add event listeners to detect new service worker updates
      wb.addEventListener('waiting', () => {
        setIsUpdateAvailable(true);
        setRegistration(wb);
      });

      wb.addEventListener('controlling', () => {
        // At this point, the new service worker has taken control
        window.location.reload();
      });

      // Register the service worker after adding event listeners
      wb.register()
        .then((r) => {
          console.log('Service Worker registered successfully');
          // Check if there's already a waiting service worker
          if (r && r.waiting) {
            setIsUpdateAvailable(true);
            setRegistration(wb);
          }
        })
        .catch((error) => {
          console.error('Service Worker registration failed:', error);
        });
    }
  }, []);

  // Function to update the service worker
  const updateServiceWorker = () => {
    if (registration) {
      registration.messageSkipWaiting();
    }
  };

  return {
    isUpdateAvailable,
    updateServiceWorker,
    isOffline,
  };
}
