import React, { createContext, useContext, useState, useEffect } from 'react';
import { useRouter } from 'next/router';

// Create auth context
const AuthContext = createContext(null);

// Provider component
export const AuthProvider = ({ children }) => {
  const [user, setUser] = useState(null);
  const [loading, setLoading] = useState(true);
  const router = useRouter();

  // Check for existing user session on mount
  useEffect(() => {
    const checkUser = async () => {
      try {
        // In a real app, this would verify the session with Supabase
        // For demo purposes, we'll check localStorage
        const storedUser = localStorage.getItem('user');
        
        if (storedUser) {
          setUser(JSON.parse(storedUser));
        }
      } catch (error) {
        console.error('Session check error:', error);
        setUser(null);
      } finally {
        setLoading(false);
      }
    };

    checkUser();
  }, []);

  // Sign in function
  const signIn = async (email, password) => {
    try {
      // In a real app, this would authenticate with Supabase
      // For demo purposes, we'll use mock authentication
      if (email === 'admin@navy.mil' && password === 'admin123') {
        const userData = {
          id: 1,
          email: 'admin@navy.mil',
          name: 'Admin User',
          role: 'admin',
          rank: 'Commander'
        };
        
        setUser(userData);
        localStorage.setItem('user', JSON.stringify(userData));
        return { success: true, user: userData };
      } else if (email === 'user@navy.mil' && password === 'user123') {
        const userData = {
          id: 2,
          email: 'user@navy.mil',
          name: 'John Smith',
          role: 'user',
          rank: 'Petty Officer'
        };
        
        setUser(userData);
        localStorage.setItem('user', JSON.stringify(userData));
        return { success: true, user: userData };
      } else {
        return { success: false, error: 'Invalid email or password' };
      }
    } catch (error) {
      console.error('Sign in error:', error);
      return { success: false, error: 'An error occurred during sign in' };
    }
  };

  // Sign out function
  const signOut = async () => {
    try {
      // In a real app, this would sign out from Supabase
      // For demo purposes, we'll just clear localStorage
      localStorage.removeItem('user');
      setUser(null);
      router.push('/login');
      return { success: true };
    } catch (error) {
      console.error('Sign out error:', error);
      return { success: false, error: 'An error occurred during sign out' };
    }
  };

  // Check if user has required role
  const hasRole = (requiredRole) => {
    if (!user) return false;
    if (requiredRole === 'admin') return user.role === 'admin';
    return true; // All authenticated users have basic 'user' role
  };

  // Context value
  const value = {
    user,
    loading,
    signIn,
    signOut,
    hasRole
  };

  return (
    <AuthContext.Provider value={value}>
      {children}
    </AuthContext.Provider>
  );
};

// Custom hook to use the auth context
export const useAuth = () => {
  const context = useContext(AuthContext);
  if (!context) {
    throw new Error('useAuth must be used within an AuthProvider');
  }
  return context;
};

// HOC to protect routes
export const withAuth = (Component, requiredRole = 'user') => {
  const WithAuth = (props) => {
    const { user, loading, hasRole } = useAuth();
    const router = useRouter();

    useEffect(() => {
      if (!loading && !user) {
        router.push('/login');
      } else if (!loading && user && requiredRole && !hasRole(requiredRole)) {
        router.push('/unauthorized');
      }
    }, [loading, user, router, requiredRole]);

    if (loading) {
      return (
        <div className="min-h-screen flex items-center justify-center bg-[#050A30]">
          <div className="text-center">
            <div className="animate-spin rounded-full h-12 w-12 border-t-2 border-b-2 border-[#FFD700] mx-auto"></div>
            <p className="mt-4 text-[#FFFFFF]">Loading...</p>
          </div>
        </div>
      );
    }

    if (!user) {
      return null;
    }

    if (requiredRole && !hasRole(requiredRole)) {
      return null;
    }

    return <Component {...props} />;
  };

  return WithAuth;
};
