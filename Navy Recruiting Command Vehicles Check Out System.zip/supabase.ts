import { createClient } from '@supabase/supabase-js';

const supabaseUrl = 'https://tgzyqycyoyzrbgjvzvzx.supabase.co';
const supabaseAnonKey = 'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6InRnenlxeWN5b3l6cmJnanZ6dnp4Iiwicm9sZSI6ImFub24iLCJpYXQiOjE3NDMzNzU2MDksImV4cCI6MjA1ODk1MTYwOX0.smPHsTDorXUKdOYxUVxQV8h2UEx_mDP-rM5Vz9MW8t8';

// Create a single supabase client for interacting with your database
export const supabase = createClient(supabaseUrl, supabaseAnonKey);

// For admin operations that require service role access
export const getServiceSupabase = () => {
  const supabaseServiceKey = 'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6InRnenlxeWN5b3l6cmJnanZ6dnp4Iiwicm9sZSI6InNlcnZpY2Vfcm9sZSIsImlhdCI6MTc0MzM3NTYwOSwiZXhwIjoyMDU4OTUxNjA5fQ.eMuA61Fk-5yPBVc0hm9nSOoQbo-qa5F90pYLlrF2mPw';
  return createClient(supabaseUrl, supabaseServiceKey);
};
