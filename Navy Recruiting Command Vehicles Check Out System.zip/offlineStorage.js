import { createContext, useContext, useState, useEffect } from 'react';
import localforage from 'localforage';

// Initialize localforage
localforage.config({
  name: 'navy-vehicle-system',
  storeName: 'vehicle_data',
  description: 'Offline storage for Navy Recruiting Command Vehicle Management System'
});

// Create context
const OfflineStorageContext = createContext(null);

// Provider component
export const OfflineStorageProvider = ({ children }) => {
  const [isOnline, setIsOnline] = useState(typeof navigator !== 'undefined' ? navigator.onLine : true);
  const [syncStatus, setSyncStatus] = useState('synced'); // 'synced', 'syncing', 'pending'
  const [pendingActions, setPendingActions] = useState([]);

  // Initialize and set up event listeners
  useEffect(() => {
    if (typeof window !== 'undefined') {
      // Set up online/offline event listeners
      const handleOnline = () => {
        setIsOnline(true);
        syncPendingActions();
      };
      
      const handleOffline = () => {
        setIsOnline(false);
        setSyncStatus('pending');
      };
      
      window.addEventListener('online', handleOnline);
      window.addEventListener('offline', handleOffline);
      
      // Check for pending actions on load
      loadPendingActions();
      
      return () => {
        window.removeEventListener('online', handleOnline);
        window.removeEventListener('offline', handleOffline);
      };
    }
  }, []);

  // Load pending actions from storage
  const loadPendingActions = async () => {
    try {
      const actions = await localforage.getItem('pendingActions') || [];
      setPendingActions(actions);
      
      if (actions.length > 0 && navigator.onLine) {
        syncPendingActions();
      } else if (actions.length > 0) {
        setSyncStatus('pending');
      }
    } catch (error) {
      console.error('Error loading pending actions:', error);
    }
  };

  // Sync pending actions with the server
  const syncPendingActions = async () => {
    if (!navigator.onLine || pendingActions.length === 0) return;
    
    setSyncStatus('syncing');
    
    try {
      // Process each pending action in order
      const actionsToProcess = [...pendingActions];
      const newPendingActions = [];
      
      for (const action of actionsToProcess) {
        try {
          // Here we would actually send the action to the server
          // For now, we'll just simulate a successful sync
          console.log('Syncing action:', action);
          
          // Simulate API call
          await new Promise(resolve => setTimeout(resolve, 500));
          
          // If successful, we don't add it to the new pending actions
        } catch (error) {
          console.error('Error syncing action:', error);
          // If failed, keep it in the pending actions
          newPendingActions.push(action);
        }
      }
      
      // Update pending actions
      setPendingActions(newPendingActions);
      await localforage.setItem('pendingActions', newPendingActions);
      
      // Update sync status
      setSyncStatus(newPendingActions.length > 0 ? 'pending' : 'synced');
    } catch (error) {
      console.error('Error syncing pending actions:', error);
      setSyncStatus('pending');
    }
  };

  // Add a new action to the pending queue
  const addPendingAction = async (action) => {
    try {
      const newPendingActions = [...pendingActions, action];
      setPendingActions(newPendingActions);
      await localforage.setItem('pendingActions', newPendingActions);
      
      // If online, try to sync immediately
      if (navigator.onLine) {
        syncPendingActions();
      } else {
        setSyncStatus('pending');
      }
    } catch (error) {
      console.error('Error adding pending action:', error);
    }
  };

  // Store data in offline storage
  const storeData = async (key, data) => {
    try {
      await localforage.setItem(key, data);
      return true;
    } catch (error) {
      console.error(`Error storing data for key ${key}:`, error);
      return false;
    }
  };

  // Retrieve data from offline storage
  const retrieveData = async (key) => {
    try {
      return await localforage.getItem(key);
    } catch (error) {
      console.error(`Error retrieving data for key ${key}:`, error);
      return null;
    }
  };

  // Remove data from offline storage
  const removeData = async (key) => {
    try {
      await localforage.removeItem(key);
      return true;
    } catch (error) {
      console.error(`Error removing data for key ${key}:`, error);
      return false;
    }
  };

  // Clear all data from offline storage
  const clearAllData = async () => {
    try {
      await localforage.clear();
      return true;
    } catch (error) {
      console.error('Error clearing all data:', error);
      return false;
    }
  };

  // Get all keys in offline storage
  const getAllKeys = async () => {
    try {
      return await localforage.keys();
    } catch (error) {
      console.error('Error getting all keys:', error);
      return [];
    }
  };

  // Perform an action with offline support
  const performAction = async (actionType, actionData, onlineCallback, offlineCallback) => {
    if (navigator.onLine) {
      // If online, perform the action immediately
      try {
        const result = await onlineCallback(actionData);
        return result;
      } catch (error) {
        console.error(`Error performing online action ${actionType}:`, error);
        
        // If online action fails, store it for later and perform offline action
        if (offlineCallback) {
          await addPendingAction({ type: actionType, data: actionData, timestamp: new Date().toISOString() });
          return offlineCallback(actionData);
        }
        
        throw error;
      }
    } else {
      // If offline, store the action for later and perform offline action
      await addPendingAction({ type: actionType, data: actionData, timestamp: new Date().toISOString() });
      
      if (offlineCallback) {
        return offlineCallback(actionData);
      }
      
      return { success: false, offline: true, message: 'Action queued for when online' };
    }
  };

  // Context value
  const value = {
    isOnline,
    syncStatus,
    pendingActions,
    storeData,
    retrieveData,
    removeData,
    clearAllData,
    getAllKeys,
    performAction,
    syncPendingActions
  };

  return (
    <OfflineStorageContext.Provider value={value}>
      {children}
    </OfflineStorageContext.Provider>
  );
};

// Custom hook to use the offline storage context
export const useOfflineStorage = () => {
  const context = useContext(OfflineStorageContext);
  if (!context) {
    throw new Error('useOfflineStorage must be used within an OfflineStorageProvider');
  }
  return context;
};
