# Navy Recruiting Command Vehicle Management System - Database Schema

## Overview
This document outlines the database schema for the Navy Recruiting Command Vehicle Management System. The schema is designed to support all the core functionality requirements including vehicle management, user management, and check-out/check-in operations.

## Tables

### 1. users
Stores information about system users including administrators and standard users.

```sql
CREATE TABLE users (
  id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  email VARCHAR(255) UNIQUE NOT NULL,
  full_name VARCHAR(255) NOT NULL,
  rank VARCHAR(100),
  phone VARCHAR(20),
  is_admin BOOLEAN DEFAULT FALSE,
  created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
  updated_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);
```

### 2. vehicles
Stores information about all vehicles in the fleet.

```sql
CREATE TABLE vehicles (
  id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  make VARCHAR(100) NOT NULL,
  model VARCHAR(100) NOT NULL,
  year INTEGER NOT NULL,
  color VARCHAR(50) NOT NULL,
  license_plate VARCHAR(20) UNIQUE NOT NULL,
  vin VARCHAR(17) UNIQUE NOT NULL,
  current_mileage INTEGER NOT NULL,
  fuel_capacity DECIMAL(5,2) NOT NULL,
  status VARCHAR(20) NOT NULL CHECK (status IN ('available', 'checked_out', 'maintenance', 'out_of_service')),
  qr_code_url VARCHAR(255),
  notes TEXT,
  created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
  updated_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);
```

### 3. vehicle_checkouts
Records all vehicle check-out transactions.

```sql
CREATE TABLE vehicle_checkouts (
  id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  vehicle_id UUID NOT NULL REFERENCES vehicles(id),
  user_id UUID NOT NULL REFERENCES users(id),
  checkout_time TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
  expected_return_time TIMESTAMP WITH TIME ZONE NOT NULL,
  destination VARCHAR(255) NOT NULL,
  purpose TEXT NOT NULL,
  starting_mileage INTEGER NOT NULL,
  starting_fuel_level DECIMAL(5,2) NOT NULL,
  condition_notes TEXT,
  condition_photos JSONB,
  is_active BOOLEAN DEFAULT TRUE,
  created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
  updated_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);
```

### 4. vehicle_checkins
Records all vehicle check-in transactions.

```sql
CREATE TABLE vehicle_checkins (
  id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  checkout_id UUID NOT NULL REFERENCES vehicle_checkouts(id),
  checkin_time TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
  ending_mileage INTEGER NOT NULL,
  ending_fuel_level DECIMAL(5,2) NOT NULL,
  condition_notes TEXT,
  condition_photos JSONB,
  maintenance_issues TEXT,
  created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
  updated_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);
```

### 5. maintenance_records
Tracks maintenance activities for vehicles.

```sql
CREATE TABLE maintenance_records (
  id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  vehicle_id UUID NOT NULL REFERENCES vehicles(id),
  maintenance_type VARCHAR(100) NOT NULL,
  description TEXT NOT NULL,
  mileage_at_maintenance INTEGER NOT NULL,
  maintenance_date DATE NOT NULL,
  cost DECIMAL(10,2),
  performed_by VARCHAR(255),
  notes TEXT,
  created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
  updated_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);
```

### 6. notifications
Stores system notifications such as overdue vehicles and maintenance reminders.

```sql
CREATE TABLE notifications (
  id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  type VARCHAR(50) NOT NULL,
  user_id UUID REFERENCES users(id),
  vehicle_id UUID REFERENCES vehicles(id),
  message TEXT NOT NULL,
  is_read BOOLEAN DEFAULT FALSE,
  created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
  updated_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);
```

### 7. system_logs
Tracks important system activities for auditing purposes.

```sql
CREATE TABLE system_logs (
  id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  user_id UUID REFERENCES users(id),
  action VARCHAR(100) NOT NULL,
  details JSONB,
  ip_address VARCHAR(45),
  created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);
```

## Indexes

```sql
-- Indexes for vehicle_checkouts table
CREATE INDEX idx_vehicle_checkouts_vehicle_id ON vehicle_checkouts(vehicle_id);
CREATE INDEX idx_vehicle_checkouts_user_id ON vehicle_checkouts(user_id);
CREATE INDEX idx_vehicle_checkouts_is_active ON vehicle_checkouts(is_active);

-- Indexes for vehicle_checkins table
CREATE INDEX idx_vehicle_checkins_checkout_id ON vehicle_checkins(checkout_id);

-- Indexes for maintenance_records table
CREATE INDEX idx_maintenance_records_vehicle_id ON maintenance_records(vehicle_id);
CREATE INDEX idx_maintenance_records_maintenance_date ON maintenance_records(maintenance_date);

-- Indexes for notifications table
CREATE INDEX idx_notifications_user_id ON notifications(user_id);
CREATE INDEX idx_notifications_is_read ON notifications(is_read);
```

## Functions and Triggers

### 1. Update vehicle status on checkout

```sql
CREATE OR REPLACE FUNCTION update_vehicle_status_on_checkout()
RETURNS TRIGGER AS $$
BEGIN
  UPDATE vehicles
  SET status = 'checked_out', updated_at = NOW()
  WHERE id = NEW.vehicle_id;
  RETURN NEW;
END;
$$ LANGUAGE plpgsql;

CREATE TRIGGER trigger_update_vehicle_status_on_checkout
AFTER INSERT ON vehicle_checkouts
FOR EACH ROW
WHEN (NEW.is_active = TRUE)
EXECUTE FUNCTION update_vehicle_status_on_checkout();
```

### 2. Update vehicle status on checkin

```sql
CREATE OR REPLACE FUNCTION update_vehicle_status_on_checkin()
RETURNS TRIGGER AS $$
BEGIN
  UPDATE vehicle_checkouts
  SET is_active = FALSE, updated_at = NOW()
  WHERE id = NEW.checkout_id;
  
  UPDATE vehicles
  SET status = 'available', 
      current_mileage = NEW.ending_mileage,
      updated_at = NOW()
  WHERE id = (SELECT vehicle_id FROM vehicle_checkouts WHERE id = NEW.checkout_id);
  
  RETURN NEW;
END;
$$ LANGUAGE plpgsql;

CREATE TRIGGER trigger_update_vehicle_status_on_checkin
AFTER INSERT ON vehicle_checkins
FOR EACH ROW
EXECUTE FUNCTION update_vehicle_status_on_checkin();
```

### 3. Create overdue vehicle notifications

```sql
CREATE OR REPLACE FUNCTION create_overdue_vehicle_notifications()
RETURNS VOID AS $$
DECLARE
  overdue_checkout RECORD;
BEGIN
  FOR overdue_checkout IN
    SELECT vc.id, vc.vehicle_id, vc.user_id, v.license_plate
    FROM vehicle_checkouts vc
    JOIN vehicles v ON vc.vehicle_id = v.id
    WHERE vc.is_active = TRUE
    AND vc.expected_return_time < NOW()
    AND NOT EXISTS (
      SELECT 1 FROM notifications n
      WHERE n.vehicle_id = vc.vehicle_id
      AND n.type = 'overdue_vehicle'
      AND n.created_at > NOW() - INTERVAL '24 hours'
    )
  LOOP
    INSERT INTO notifications (
      type, user_id, vehicle_id, message
    ) VALUES (
      'overdue_vehicle',
      overdue_checkout.user_id,
      overdue_checkout.vehicle_id,
      'Vehicle with license plate ' || overdue_checkout.license_plate || ' is overdue for return.'
    );
  END LOOP;
END;
$$ LANGUAGE plpgsql;
```

## Row Level Security Policies

```sql
-- Enable RLS on all tables
ALTER TABLE users ENABLE ROW LEVEL SECURITY;
ALTER TABLE vehicles ENABLE ROW LEVEL SECURITY;
ALTER TABLE vehicle_checkouts ENABLE ROW LEVEL SECURITY;
ALTER TABLE vehicle_checkins ENABLE ROW LEVEL SECURITY;
ALTER TABLE maintenance_records ENABLE ROW LEVEL SECURITY;
ALTER TABLE notifications ENABLE ROW LEVEL SECURITY;
ALTER TABLE system_logs ENABLE ROW LEVEL SECURITY;

-- Create policies for users table
CREATE POLICY users_select_policy ON users
  FOR SELECT USING (auth.uid() = id OR EXISTS (SELECT 1 FROM users WHERE id = auth.uid() AND is_admin = TRUE));

CREATE POLICY users_insert_policy ON users
  FOR INSERT WITH CHECK (auth.uid() = id OR EXISTS (SELECT 1 FROM users WHERE id = auth.uid() AND is_admin = TRUE));

CREATE POLICY users_update_policy ON users
  FOR UPDATE USING (auth.uid() = id OR EXISTS (SELECT 1 FROM users WHERE id = auth.uid() AND is_admin = TRUE));

-- Create policies for vehicles table
CREATE POLICY vehicles_select_policy ON vehicles
  FOR SELECT USING (TRUE);

CREATE POLICY vehicles_insert_policy ON vehicles
  FOR INSERT WITH CHECK (EXISTS (SELECT 1 FROM users WHERE id = auth.uid() AND is_admin = TRUE));

CREATE POLICY vehicles_update_policy ON vehicles
  FOR UPDATE USING (EXISTS (SELECT 1 FROM users WHERE id = auth.uid() AND is_admin = TRUE));

-- Create policies for vehicle_checkouts table
CREATE POLICY vehicle_checkouts_select_policy ON vehicle_checkouts
  FOR SELECT USING (TRUE);

CREATE POLICY vehicle_checkouts_insert_policy ON vehicle_checkouts
  FOR INSERT WITH CHECK (auth.uid() = user_id OR EXISTS (SELECT 1 FROM users WHERE id = auth.uid() AND is_admin = TRUE));

-- Create policies for vehicle_checkins table
CREATE POLICY vehicle_checkins_select_policy ON vehicle_checkins
  FOR SELECT USING (TRUE);

CREATE POLICY vehicle_checkins_insert_policy ON vehicle_checkins
  FOR INSERT WITH CHECK (
    EXISTS (
      SELECT 1 FROM vehicle_checkouts vc
      WHERE vc.id = checkout_id
      AND (vc.user_id = auth.uid() OR EXISTS (SELECT 1 FROM users WHERE id = auth.uid() AND is_admin = TRUE))
    )
  );
```

## Database Relationships Diagram

```
users
  ↑
  |
  +--> vehicle_checkouts <-- vehicles
  |         |
  |         v
  +--> vehicle_checkins
  |
  +--> notifications <-- vehicles
  |
  +--> system_logs

vehicles
  |
  +--> maintenance_records
```

This schema provides a comprehensive foundation for the Navy Recruiting Command Vehicle Management System, supporting all the required functionality while maintaining data integrity and security.
