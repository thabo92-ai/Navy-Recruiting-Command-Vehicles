import React from 'react';
import NavBar from '@/components/ui/NavBar';
import Sidebar from '@/components/ui/Sidebar';

interface LayoutProps {
  children: React.ReactNode;
}

const Layout: React.FC<LayoutProps> = ({ children }) => {
  return (
    <div className="min-h-screen bg-[#050A30]">
      <NavBar />
      <div className="flex">
        <Sidebar />
        <main className="ml-64 p-6 w-full">
          {children}
        </main>
      </div>
    </div>
  );
};

export default Layout;
