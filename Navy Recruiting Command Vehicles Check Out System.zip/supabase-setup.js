import { supabase, getServiceSupabase } from './supabase';

// This script sets up the Supabase database schema for the Navy Recruiting Command Vehicle Management System

async function setupDatabase() {
  const serviceSupabase = getServiceSupabase();
  
  console.log('Starting database setup...');
  
  try {
    // Enable UUID extension
    console.log('Enabling UUID extension...');
    await serviceSupabase.rpc('extensions', { 
      command: 'CREATE EXTENSION IF NOT EXISTS "uuid-ossp"' 
    });
    
    // Create users table
    console.log('Creating users table...');
    await serviceSupabase.rpc('create_table', {
      table_name: 'users',
      definition: `
        id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
        email VARCHAR(255) UNIQUE NOT NULL,
        full_name VARCHAR(255) NOT NULL,
        rank VARCHAR(100),
        phone VARCHAR(20),
        is_admin BOOLEAN DEFAULT FALSE,
        created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
        updated_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
      `
    });
    
    // Create vehicles table
    console.log('Creating vehicles table...');
    await serviceSupabase.rpc('create_table', {
      table_name: 'vehicles',
      definition: `
        id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
        make VARCHAR(100) NOT NULL,
        model VARCHAR(100) NOT NULL,
        year INTEGER NOT NULL,
        color VARCHAR(50) NOT NULL,
        license_plate VARCHAR(20) UNIQUE NOT NULL,
        vin VARCHAR(17) UNIQUE NOT NULL,
        current_mileage INTEGER NOT NULL,
        fuel_capacity DECIMAL(5,2) NOT NULL,
        status VARCHAR(20) NOT NULL CHECK (status IN ('available', 'checked_out', 'maintenance', 'out_of_service')),
        qr_code_url VARCHAR(255),
        notes TEXT,
        created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
        updated_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
      `
    });
    
    // Create vehicle_checkouts table
    console.log('Creating vehicle_checkouts table...');
    await serviceSupabase.rpc('create_table', {
      table_name: 'vehicle_checkouts',
      definition: `
        id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
        vehicle_id UUID NOT NULL REFERENCES vehicles(id),
        user_id UUID NOT NULL REFERENCES users(id),
        checkout_time TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
        expected_return_time TIMESTAMP WITH TIME ZONE NOT NULL,
        destination VARCHAR(255) NOT NULL,
        purpose TEXT NOT NULL,
        starting_mileage INTEGER NOT NULL,
        starting_fuel_level DECIMAL(5,2) NOT NULL,
        condition_notes TEXT,
        condition_photos JSONB,
        is_active BOOLEAN DEFAULT TRUE,
        created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
        updated_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
      `
    });
    
    // Create vehicle_checkins table
    console.log('Creating vehicle_checkins table...');
    await serviceSupabase.rpc('create_table', {
      table_name: 'vehicle_checkins',
      definition: `
        id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
        checkout_id UUID NOT NULL REFERENCES vehicle_checkouts(id),
        checkin_time TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
        ending_mileage INTEGER NOT NULL,
        ending_fuel_level DECIMAL(5,2) NOT NULL,
        condition_notes TEXT,
        condition_photos JSONB,
        maintenance_issues TEXT,
        created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
        updated_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
      `
    });
    
    // Create maintenance_records table
    console.log('Creating maintenance_records table...');
    await serviceSupabase.rpc('create_table', {
      table_name: 'maintenance_records',
      definition: `
        id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
        vehicle_id UUID NOT NULL REFERENCES vehicles(id),
        maintenance_type VARCHAR(100) NOT NULL,
        description TEXT NOT NULL,
        mileage_at_maintenance INTEGER NOT NULL,
        maintenance_date DATE NOT NULL,
        cost DECIMAL(10,2),
        performed_by VARCHAR(255),
        notes TEXT,
        created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
        updated_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
      `
    });
    
    // Create notifications table
    console.log('Creating notifications table...');
    await serviceSupabase.rpc('create_table', {
      table_name: 'notifications',
      definition: `
        id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
        type VARCHAR(50) NOT NULL,
        user_id UUID REFERENCES users(id),
        vehicle_id UUID REFERENCES vehicles(id),
        message TEXT NOT NULL,
        is_read BOOLEAN DEFAULT FALSE,
        created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
        updated_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
      `
    });
    
    // Create system_logs table
    console.log('Creating system_logs table...');
    await serviceSupabase.rpc('create_table', {
      table_name: 'system_logs',
      definition: `
        id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
        user_id UUID REFERENCES users(id),
        action VARCHAR(100) NOT NULL,
        details JSONB,
        ip_address VARCHAR(45),
        created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
      `
    });
    
    // Create indexes
    console.log('Creating indexes...');
    await serviceSupabase.rpc('execute_sql', {
      sql: `
        -- Indexes for vehicle_checkouts table
        CREATE INDEX IF NOT EXISTS idx_vehicle_checkouts_vehicle_id ON vehicle_checkouts(vehicle_id);
        CREATE INDEX IF NOT EXISTS idx_vehicle_checkouts_user_id ON vehicle_checkouts(user_id);
        CREATE INDEX IF NOT EXISTS idx_vehicle_checkouts_is_active ON vehicle_checkouts(is_active);
        
        -- Indexes for vehicle_checkins table
        CREATE INDEX IF NOT EXISTS idx_vehicle_checkins_checkout_id ON vehicle_checkins(checkout_id);
        
        -- Indexes for maintenance_records table
        CREATE INDEX IF NOT EXISTS idx_maintenance_records_vehicle_id ON maintenance_records(vehicle_id);
        CREATE INDEX IF NOT EXISTS idx_maintenance_records_maintenance_date ON maintenance_records(maintenance_date);
        
        -- Indexes for notifications table
        CREATE INDEX IF NOT EXISTS idx_notifications_user_id ON notifications(user_id);
        CREATE INDEX IF NOT EXISTS idx_notifications_is_read ON notifications(is_read);
      `
    });
    
    // Create functions and triggers
    console.log('Creating functions and triggers...');
    await serviceSupabase.rpc('execute_sql', {
      sql: `
        -- Update vehicle status on checkout
        CREATE OR REPLACE FUNCTION update_vehicle_status_on_checkout()
        RETURNS TRIGGER AS $$
        BEGIN
          UPDATE vehicles
          SET status = 'checked_out', updated_at = NOW()
          WHERE id = NEW.vehicle_id;
          RETURN NEW;
        END;
        $$ LANGUAGE plpgsql;
        
        DROP TRIGGER IF EXISTS trigger_update_vehicle_status_on_checkout ON vehicle_checkouts;
        CREATE TRIGGER trigger_update_vehicle_status_on_checkout
        AFTER INSERT ON vehicle_checkouts
        FOR EACH ROW
        WHEN (NEW.is_active = TRUE)
        EXECUTE FUNCTION update_vehicle_status_on_checkout();
        
        -- Update vehicle status on checkin
        CREATE OR REPLACE FUNCTION update_vehicle_status_on_checkin()
        RETURNS TRIGGER AS $$
        BEGIN
          UPDATE vehicle_checkouts
          SET is_active = FALSE, updated_at = NOW()
          WHERE id = NEW.checkout_id;
          
          UPDATE vehicles
          SET status = 'available', 
              current_mileage = NEW.ending_mileage,
              updated_at = NOW()
          WHERE id = (SELECT vehicle_id FROM vehicle_checkouts WHERE id = NEW.checkout_id);
          
          RETURN NEW;
        END;
        $$ LANGUAGE plpgsql;
        
        DROP TRIGGER IF EXISTS trigger_update_vehicle_status_on_checkin ON vehicle_checkins;
        CREATE TRIGGER trigger_update_vehicle_status_on_checkin
        AFTER INSERT ON vehicle_checkins
        FOR EACH ROW
        EXECUTE FUNCTION update_vehicle_status_on_checkin();
        
        -- Create overdue vehicle notifications
        CREATE OR REPLACE FUNCTION create_overdue_vehicle_notifications()
        RETURNS VOID AS $$
        DECLARE
          overdue_checkout RECORD;
        BEGIN
          FOR overdue_checkout IN
            SELECT vc.id, vc.vehicle_id, vc.user_id, v.license_plate
            FROM vehicle_checkouts vc
            JOIN vehicles v ON vc.vehicle_id = v.id
            WHERE vc.is_active = TRUE
            AND vc.expected_return_time < NOW()
            AND NOT EXISTS (
              SELECT 1 FROM notifications n
              WHERE n.vehicle_id = vc.vehicle_id
              AND n.type = 'overdue_vehicle'
              AND n.created_at > NOW() - INTERVAL '24 hours'
            )
          LOOP
            INSERT INTO notifications (
              type, user_id, vehicle_id, message
            ) VALUES (
              'overdue_vehicle',
              overdue_checkout.user_id,
              overdue_checkout.vehicle_id,
              'Vehicle with license plate ' || overdue_checkout.license_plate || ' is overdue for return.'
            );
          END LOOP;
        END;
        $$ LANGUAGE plpgsql;
      `
    });
    
    // Enable Row Level Security
    console.log('Enabling Row Level Security...');
    await serviceSupabase.rpc('execute_sql', {
      sql: `
        -- Enable RLS on all tables
        ALTER TABLE users ENABLE ROW LEVEL SECURITY;
        ALTER TABLE vehicles ENABLE ROW LEVEL SECURITY;
        ALTER TABLE vehicle_checkouts ENABLE ROW LEVEL SECURITY;
        ALTER TABLE vehicle_checkins ENABLE ROW LEVEL SECURITY;
        ALTER TABLE maintenance_records ENABLE ROW LEVEL SECURITY;
        ALTER TABLE notifications ENABLE ROW LEVEL SECURITY;
        ALTER TABLE system_logs ENABLE ROW LEVEL SECURITY;
        
        -- Create policies for users table
        CREATE POLICY IF NOT EXISTS users_select_policy ON users
          FOR SELECT USING (auth.uid() = id OR EXISTS (SELECT 1 FROM users WHERE id = auth.uid() AND is_admin = TRUE));
        
        CREATE POLICY IF NOT EXISTS users_insert_policy ON users
          FOR INSERT WITH CHECK (auth.uid() = id OR EXISTS (SELECT 1 FROM users WHERE id = auth.uid() AND is_admin = TRUE));
        
        CREATE POLICY IF NOT EXISTS users_update_policy ON users
          FOR UPDATE USING (auth.uid() = id OR EXISTS (SELECT 1 FROM users WHERE id = auth.uid() AND is_admin = TRUE));
        
        -- Create policies for vehicles table
        CREATE POLICY IF NOT EXISTS vehicles_select_policy ON vehicles
          FOR SELECT USING (TRUE);
        
        CREATE POLICY IF NOT EXISTS vehicles_insert_policy ON vehicles
          FOR INSERT WITH CHECK (EXISTS (SELECT 1 FROM users WHERE id = auth.uid() AND is_admin = TRUE));
        
        CREATE POLICY IF NOT EXISTS vehicles_update_policy ON vehicles
          FOR UPDATE USING (EXISTS (SELECT 1 FROM users WHERE id = auth.uid() AND is_admin = TRUE));
        
        -- Create policies for vehicle_checkouts table
        CREATE POLICY IF NOT EXISTS vehicle_checkouts_select_policy ON vehicle_checkouts
          FOR SELECT USING (TRUE);
        
        CREATE POLICY IF NOT EXISTS vehicle_checkouts_insert_policy ON vehicle_checkouts
          FOR INSERT WITH CHECK (auth.uid() = user_id OR EXISTS (SELECT 1 FROM users WHERE id = auth.uid() AND is_admin = TRUE));
        
        -- Create policies for vehicle_checkins table
        CREATE POLICY IF NOT EXISTS vehicle_checkins_select_policy ON vehicle_checkins
          FOR SELECT USING (TRUE);
        
        CREATE POLICY IF NOT EXISTS vehicle_checkins_insert_policy ON vehicle_checkins
          FOR INSERT WITH CHECK (
            EXISTS (
              SELECT 1 FROM vehicle_checkouts vc
              WHERE vc.id = checkout_id
              AND (vc.user_id = auth.uid() OR EXISTS (SELECT 1 FROM users WHERE id = auth.uid() AND is_admin = TRUE))
            )
          );
      `
    });
    
    console.log('Database setup completed successfully!');
    return { success: true, message: 'Database setup completed successfully!' };
  } catch (error) {
    console.error('Error setting up database:', error);
    return { success: false, error: error.message };
  }
}

export { setupDatabase };
